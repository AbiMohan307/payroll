package com.virtusa.payroll.model;

public class Payslip {

	String empid;

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}
}
