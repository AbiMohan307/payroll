package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salary")
public class Salary {
	
	@Id
	@Column
	String e_id;
	@Column
	float ctc;
	Salary()
	{
		
	}
	public String getE_id() {
		return e_id;
	}
	public void setE_id(String e_id) {
		this.e_id = e_id;
	}
	public float getCtc() {
		return ctc;
	}
	public void setCtc(float ctc) {
		this.ctc = ctc;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	@Column
	int designation_id;
	public Salary(String e_id, float ctc, int designation_id) {
		super();
		this.e_id = e_id;
		this.ctc = ctc;
		this.designation_id = designation_id;
	}
	

}
