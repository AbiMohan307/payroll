package com.virtusa.payroll.controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Attendance;
import com.virtusa.payroll.model.Designation;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Salary;
import com.virtusa.payroll.model.Year;
import com.virtusa.payroll.services.PaySlipService;


@Controller

public class PaySlipController {
	
	@Autowired
	PaySlipService paySlipService;
	@RequestMapping(value="/payslip",method=RequestMethod.GET)
	public ModelAndView selectOption(HttpServletRequest request,HttpServletResponse response)
	{
		ModelAndView mav=new ModelAndView("payslip");
		return mav;
		
	}
	@RequestMapping(value="/GeneratePayslip",method=RequestMethod.POST)
	public String showPaySlip(HttpSession session,
			@ModelAttribute("year") Year year,ModelMap mav)
	{
		
		System.out.println(year.getYear()+" "+year.getMonth());
		String empid="1";
		List<Attendance> hoursWorked=paySlipService.getHoursWorked(empid, year.getMonth(), year.getYear());
		List<Salary> ctc=paySlipService.getSalary(empid);
		List<Employee> employee=paySlipService.getEmployee(empid);
		List<Designation> designation=paySlipService.getDesignation(employee.get(0).getDesignation_id());
		mav.addAttribute("hoursWorked", hoursWorked);
		mav.addAttribute("ctc", ctc);
		mav.addAttribute("year", year);
		mav.addAttribute("designation", designation);
		mav.addAttribute("employee", employee);
		return "showPaySlip";
		
	}

}
