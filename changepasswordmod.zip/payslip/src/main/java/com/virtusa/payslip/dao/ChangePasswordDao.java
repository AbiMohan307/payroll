package com.virtusa.payslip.dao;

import java.util.List;

import com.virtusa.payslip.model.Employee;

public interface ChangePasswordDao {
	

	public Employee getEmployeeById(String empid);

	public void updatePassword(Employee employee);

}
