package com.virtusa.payslip.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payslip.model.Employee;
import com.virtusa.payslip.service.ChangePasswordService;

@Controller
public class ChangePasswordController {
	
@Autowired
ChangePasswordService changePasswordService;

@RequestMapping(value = "/change", method = RequestMethod.GET)
  public ModelAndView change(){
	 String empid="1";
	  Employee employee=changePasswordService.getEmployeeById(empid);
	  
	 ModelAndView mav = new ModelAndView();
	 mav.addObject("employee", employee);
	 mav.setViewName("changePassword");
	 return mav;
}

@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
  public ModelAndView changePassword(HttpSession session,
      @RequestParam("oldPassword") String oldPassword,
      @RequestParam("newPassword") String newPassword,
      @RequestParam("confirmPassword") String confirmPassword) {
  
	  ModelAndView mav = null;
	  String empid="1";
	  Employee employee=changePasswordService.getEmployeeById(empid);
  
	
    if(oldPassword.equals(newPassword)) {
      mav = new ModelAndView("changePassword");
      mav.addObject("message", "old Password and new Password should be different ");
    }
    if(!newPassword.equals(confirmPassword)) {
      mav = new ModelAndView("changePassword");
      mav.addObject("message", "new Password and confirm Password should be same");
    }
    else {
      employee.setPassword(newPassword);
      mav = new ModelAndView("index");
      mav.addObject("message", "Password changed successful");
    }
    return mav;

}
}
