package com.virtusa.payslip.service;

import java.util.List;

import com.virtusa.payslip.model.Employee;

public interface ChangePasswordService {

		
	public Employee getEmployeeById(String empid);
	
	public void updatePassword(Employee employee);
}
