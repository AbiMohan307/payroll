package com.virtusa.payroll.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.models.PDFGenerator;
import com.virtusa.payroll.models.Rating;
import com.virtusa.payroll.models.Salary;
import com.virtusa.payroll.service.MboPayoutService;

@Controller
public class MBOPayout {
	
	@Autowired
	MboPayoutService mboPayoutService;
	
	Logger log = Logger.getLogger(this.getClass());
	
	@RequestMapping(value = "/mbo", method = RequestMethod.GET)
	  public ModelAndView mbo(){
		try {
		String log4jConfigFile = "C:\\Users\\sushmithana\\eclipse-workspace\\mbo\\src\\main\\webapp\\WEB-INF\\log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		log.info("This is /mbo Page Log");
		
		ModelAndView mav = new ModelAndView();
		
		Employee employee = mboPayoutService.getEmployeeDetails("1");
		
		Rating rating = mboPayoutService.getRatingDetails("1");
		
		Salary salary = mboPayoutService.getSalaryDetails("1");
		
		float ctc = salary.getCtc();
		// int previous_rating = rating.getH1_rating();
		 int current = rating.getH2_rating();
		 
		 float eligible_pay = (float) (ctc * 0.2);
		 float variable_pay;
		
		 if(current >= 4) {
			 variable_pay = eligible_pay;
		 }
		 else if(current >=2 && current <=3) {
			 variable_pay = (float) (eligible_pay * 0.5);
		 }
		 else {
			variable_pay = 0;
		 }
		 
		 PDFGenerator pdfGenerator = new PDFGenerator(employee.getEmp_id(), employee.getEmp_name(), employee.getDesignation_id(), 
				 ctc, eligible_pay, rating.getH1_rating(), current, variable_pay);
		 mav.addObject("pdf", pdfGenerator);
		 mav.setViewName("mboDisplay");
		return mav;
		
		}catch(Exception e) {
			log.error("Error is " + e);
		}
		return null;
		
	}
	

	@RequestMapping(value = "/mboPayout", method = RequestMethod.POST)
	public ModelAndView mboPayout(@ModelAttribute("pdf") PDFGenerator pdfGenerator){
		try {
			String log4jConfigFile = "C:\\Users\\sushmithana\\eclipse-workspace\\mbo\\src\\main\\webapp\\WEB-INF\\log4j.properties";
			PropertyConfigurator.configure(log4jConfigFile);
			log.info("This is /mbo Page Log");
			
		// System.out.println("MBO Controller");
				
		 return new ModelAndView("pdf","pdfGenerator",pdfGenerator);
		    	  
		      
}catch(Exception e) {
	log.error("Error is " + e);
}
return null;
	}
}
	
	
	

