package com.virtusa.payroll.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.MBODAO;
import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.models.Rating;
import com.virtusa.payroll.models.Salary;

@Service
@Transactional
public class MboPayoutService {
	
	@Autowired
	MBODAO mboDao;
	
	
	public void setMboDao(MBODAO mboDao) {
		this.mboDao = mboDao;
	}

	@Transactional
	public Employee getEmployeeDetails(String empid)
	{
		return mboDao.getEmployeeDetails(empid);
	
	}
	@Transactional
	public Salary getSalaryDetails(String empid) {
		return mboDao.getSalaryDetails(empid);
	
	}
	@Transactional
	public Rating getRatingDetails(String empid) {
	
		return mboDao.getRatingDetails(empid);
	}
}
