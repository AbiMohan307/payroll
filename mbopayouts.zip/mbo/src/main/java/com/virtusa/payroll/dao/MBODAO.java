package com.virtusa.payroll.dao;

import java.sql.Date;
import java.time.LocalDate;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.models.Rating;
import com.virtusa.payroll.models.Salary;



@Repository
public class MBODAO 
{		
		@Autowired
		SessionFactory sessionFactory;

		
		@Transactional
	public Employee getEmployeeDetails(String empid)
	{
		
		Employee employee=(Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
		
        return employee;
}
		

		@Transactional
	public Salary getSalaryDetails(String empid)
	{
		
			Salary salary=(Salary) sessionFactory.getCurrentSession().get(Salary.class, empid);
		
        return salary;
}
		
		@Transactional
		public Rating getRatingDetails(String empid)
		{
			
				Rating rating=(Rating) sessionFactory.getCurrentSession().get(Rating.class, empid);
			
	        return rating;
	}
	
		

}
