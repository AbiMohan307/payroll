package com.virtusa.payroll.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.models.Rating;
import com.virtusa.payroll.models.Salary;

@Repository
public class MboPayoutDaoImpl implements MboPayoutDao{
	@Autowired
	SessionFactory sessionFactory;

	
	@Transactional
public Employee getEmployeeDetails(String empid)
{
	
	Employee employee=(Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
	
    return employee;
}
	

	@Transactional
public Salary getSalaryDetails(String empid)
{
	
		Salary salary=(Salary) sessionFactory.getCurrentSession().get(Salary.class, empid);
	
    return salary;
}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Rating> getRatingDetails(String empid, int year)
	{
		
			Query query= sessionFactory.getCurrentSession().createQuery("from Rating r where r.emp_id = :empid" 
			+" and r.year= :year");
		
			query.setParameter("empid", empid);
			query.setParameter("year", year);
			
			
        return query.list();
}
}
