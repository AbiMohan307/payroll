package com.virtusa.payroll.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.MboPayoutDao;
import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.models.Rating;
import com.virtusa.payroll.models.Salary;


public interface MboPayoutService {
	
	
	public void setMboDao(MboPayoutDao mboDao); 
	
	public Employee getEmployeeDetails(String empid);
	
	public Salary getSalaryDetails(String empid); 
	
	public List<Rating> getRatingDetails(String empid, int year);
}
