package com.virtusa.payroll.models;

public class PDFGenerator {
	
	String emp_id;
	String emp_name;
	int designation_id;
	float ctc;
	float eligible_pay;
	int year;
	int rating;
	float variable_pay;
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public float getCtc() {
		return ctc;
	}
	public void setCtc(float ctc) {
		this.ctc = ctc;
	}
	public float getEligible_pay() {
		return eligible_pay;
	}
	public void setEligible_pay(float eligible_pay) {
		this.eligible_pay = eligible_pay;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public float getVariable_pay() {
		return variable_pay;
	}
	public void setVariable_pay(float variable_pay) {
		this.variable_pay = variable_pay;
	}
	public PDFGenerator(String emp_id, String emp_name, int designation_id, float ctc, float eligible_pay, int year,
			int rating, float variable_pay) {
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.designation_id = designation_id;
		this.ctc = ctc;
		this.eligible_pay = eligible_pay;
		this.year = year;
		this.rating = rating;
		this.variable_pay = variable_pay;
	}
	public PDFGenerator() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PDFGenerator [emp_id=" + emp_id + ", emp_name=" + emp_name + ", designation_id=" + designation_id
				+ ", ctc=" + ctc + ", eligible_pay=" + eligible_pay + ", year=" + year + ", rating=" + rating
				+ ", variable_pay=" + variable_pay + "]";
	}
	
	
}
