package com.virtusa.payroll.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@Column
	String emp_id;
	@Column
	String emp_name;
	@Column
	String password;
	@Column
	String email;
	@Column
	String mobile_no;
	@Column
	Date joining_date;
	@Column
	int designation_id;
	@Column
	float experience;
	
	  public Employee() { 
		  
	  }

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email_id) {
		this.email = email_id;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public Date getJoining_date() {
		return joining_date;
	}

	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;
	}

	public int getDesignation_id() {
		return designation_id;
	}

	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}

	public float getExperience() {
		return experience;
	}

	public void setExperience(float experience) {
		this.experience = experience;
	}

	public Employee(String emp_id, String emp_name, String password, String email_id, String mobile_no,
			Date joining_date, int designation_id, float experience) {
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.password = password;
		this.email = email_id;
		this.mobile_no = mobile_no;
		this.joining_date = joining_date;
		this.designation_id = designation_id;
		this.experience = experience;
	}
	  
	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", password=" + password + ", email_id="
				+ email + ", mobile_no=" + mobile_no + ", joining_date=" + joining_date + ", designation_id="
				+ designation_id + ", experience=" + experience + "]";
	}
	
}
