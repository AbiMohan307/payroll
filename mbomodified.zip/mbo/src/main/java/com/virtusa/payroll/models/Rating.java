package com.virtusa.payroll.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="rating")
public class Rating {
	
	@Id
	@Column
	String emp_id;
	@Column
	int h1_rating;
	@Column
	int h2_rating;
	@Column
	int year;
	public Rating() {
		// TODO Auto-generated constructor stub
	}
	public Rating(String emp_id, int h1_rating, int h2_rating,int year) {
		this.emp_id = emp_id;
		this.h1_rating = h1_rating;
		this.h2_rating = h2_rating;
		this.year = year;
	}
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public int getH1_rating() {
		return h1_rating;
	}
	public void setH1_rating(int h1_rating) {
		this.h1_rating = h1_rating;
	}
	public int getH2_rating() {
		return h2_rating;
	}
	public void setH2_rating(int h2_rating) {
		this.h2_rating = h2_rating;
	}
	@Override
	public String toString() {
		return "Rating [emp_id=" + emp_id + ", h1_rating=" + h1_rating + ", h2_rating=" + h2_rating + "]";
	}
	

}
