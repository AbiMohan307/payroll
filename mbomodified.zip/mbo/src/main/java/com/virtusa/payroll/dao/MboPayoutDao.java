package com.virtusa.payroll.dao;

import java.util.List;

import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.models.Rating;
import com.virtusa.payroll.models.Salary;




public interface MboPayoutDao 
{		
	
	public Employee getEmployeeDetails(String empid);
	
	public Salary getSalaryDetails(String empid);
	
	public List<Rating> getRatingDetails(String empid, int year);
		
		

}
