package com.virtusa.payroll.service;


import com.virtusa.payroll.model.Employee;

public interface MboPayoutService {
	
	
	public int MBOPayout(int empid);
	public Employee getUserById(int empid);		
	public float getMBO(int year,String quarter,int eid);
}
