package com.virtusa.payroll.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Salary;
import com.virtusa.payroll.model.Year;
import com.virtusa.payroll.service.PaySlipService;

@Controller
@SessionAttributes()
public class PaySlipController {
	
	@Autowired
	PaySlipService paySlipService;
	@RequestMapping(value="/payslip",method=RequestMethod.GET)
	public ModelAndView selectOption(HttpServletRequest request,HttpServletResponse response)
	{
		ModelAndView mav=new ModelAndView("payslip");
		return mav;
		
	}
	@RequestMapping(value="/GeneratePayslip",method=RequestMethod.POST)
	public ModelAndView showPaySlip(HttpServletRequest request,HttpServletResponse response,HttpSession session,
			@ModelAttribute("year") Year year)
	{
		ModelAndView mav=new ModelAndView();
		System.out.println(year.getYear()+" "+year.getMonth());
		int empid=(Integer) session.getAttribute("empid");
		List<Salary> sal=paySlipService.getSalary(empid, year.getYear(), year.getMonth());
		System.out.println(sal.get(0).getInsurance());
		mav.setViewName("showPaySlip");
		mav.addObject("salary",sal);
		return mav;
		
	}

}
