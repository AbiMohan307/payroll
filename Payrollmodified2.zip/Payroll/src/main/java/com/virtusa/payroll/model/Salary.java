package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salary")
public class Salary {
	
	@Id
	@Column
	int salary_id;
	@Column
	int designationid;
	@Column
	int empid;
	@Column
	float pf;
	@Column
	float allowances;
	@Column
	float insurance;
	@Column
	float per_hour_salary;
	@Column
	float hours_worked;
	@Column
	String month;
	@Column
	int year;
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getSalary_id() {
		return salary_id;
	}
	public void setSalary_id(int salary_id) {
		this.salary_id = salary_id;
	}
	public int getDesignation_id() {
		return designationid;
	}
	public void setDesignation_id(int designationid) {
		this.
		designationid = designationid;
	}	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int emp_id) {
		this.empid = emp_id;
	}
	public float getPf() {
		return pf;
	}
	public void setPf(float pf) {
		this.pf = pf;
	}
	public float getAllowance() {
		return allowances;
	}
	public void setAllowance(float allowances) {
		this.allowances = allowances;
	}
	public float getInsurance() {
		return insurance;
	}
	public void setInsurance(float insurance) {
		this.insurance = insurance;
	}
	public float getPer_hour_salary() {
		return per_hour_salary;
	}
	public void setPer_hour_salary(float per_hour_salary) {
		this.per_hour_salary = per_hour_salary;
	}
	public float getHours_worked() {
		return hours_worked;
	}
	public void setHours_worked(float hours_worked) {
		this.hours_worked = hours_worked;
	}
	
	public Salary() {
		// TODO Auto-generated constructor stub
		
	}
	public Salary(int salary_id, int designationid, int empid, float pf,
			float allowances, float insurance, float per_hour_salary,
			float hours_worked, String month, int year) {
		super();
		this.salary_id = salary_id;
		this.designationid = designationid;
		this.empid = empid;
		this.pf = pf;
		this.allowances = allowances;
		this.insurance = insurance;
		this.per_hour_salary = per_hour_salary;
		this.hours_worked = hours_worked;
		this.month = month;
		this.year = year;
	}
	
	
	

}
