package com.virtusa.payroll.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.User;

@Repository   
public class ChangePasswordDaoImpl implements ChangePasswordDao{

	
	@Autowired
	SessionFactory sessionFactory;
	
	

	public void updatePassword(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(user);
		user.setPassword(user.getPassword());
	}



	public User getUserById(int empid) {
		// TODO Auto-generated method stub
		return (User) sessionFactory.getCurrentSession().get(User.class, empid);
	}
	
	public List<User> listUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		List<User> usersList = session.createQuery("from User").list();
		for(User u : usersList){
			System.out.println(u.toString());
		}
		return usersList;
	}



	public void updatePassword(User user, String newPassword) {
		sessionFactory.getCurrentSession().update(user);
		user.setPassword(newPassword);
		
	}

}
