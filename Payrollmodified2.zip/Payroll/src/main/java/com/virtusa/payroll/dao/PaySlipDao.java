package com.virtusa.payroll.dao;

import java.util.List;

import com.virtusa.payroll.model.Salary;



public interface PaySlipDao {
	
	public List<Salary> getSalary(int empid,int year,String month);

}
