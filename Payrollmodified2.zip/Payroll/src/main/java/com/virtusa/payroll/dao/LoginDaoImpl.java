package com.virtusa.payroll.dao;



import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.User;

@Repository
public class LoginDaoImpl implements LoginDao{

	@Autowired
	SessionFactory sessionFactory;
	public int validateEmployee(User login) {
		// TODO Auto-generated method stub
		User log=(User) sessionFactory.getCurrentSession().get(User.class,login.getEmployee_id());
		if(login.getPassword().equals(log.getPassword()))
		{
			return 1;
		}
		else
		{
		return 0;
		}
			}
	
}
