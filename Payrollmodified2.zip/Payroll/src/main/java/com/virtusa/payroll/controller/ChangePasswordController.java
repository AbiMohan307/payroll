package com.virtusa.payroll.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Password;
import com.virtusa.payroll.model.User;
import com.virtusa.payroll.service.ChangePasswordService;

@Controller
public class ChangePasswordController {
	
@Autowired
ChangePasswordService changePasswordService;


@RequestMapping(value = "/change", method = RequestMethod.GET)
  public ModelAndView change(){
	 ModelAndView mav = new ModelAndView();
	 changePasswordService.listUsers();
	Password password=new Password();
	mav.addObject("password",password);
	mav.setViewName("setPassword");
	return mav;
	
}
@RequestMapping(value = "/ChangePassword", method = RequestMethod.POST)
  public ModelAndView changePassword(HttpServletRequest request, HttpServletResponse response,HttpSession session,
      @ModelAttribute("password") Password password) {
  
	String oldPassword=password.getOldPassword();
   String newPassword=password.getNewPassword();
   String confirmPassword=password.getConfirmPassword();
   password=new Password(oldPassword,newPassword,confirmPassword);
     ModelAndView mav = null;
     int empid=(Integer) session.getAttribute("empid");
      User user=changePasswordService.getUserById(empid);
      System.out.println("User "+user.getEmployee_id()+user.getPassword());
      System.out.println("Change "+oldPassword+" "+newPassword+" "+confirmPassword);
	if(!user.getPassword().equals(oldPassword)) {
		System.out.println("Not matching");
		mav = new ModelAndView("setPassword");
	    mav.addObject("message", "Kindly recheck the Old Password");
	}
    if(oldPassword.equals(newPassword)) {
      mav = new ModelAndView("setPassword");
      mav.addObject("message", "Old Password and New Password should not be same ");
    }
    else if(!newPassword.equals(confirmPassword)) {
      mav = new ModelAndView("setPassword");
      mav.addObject("message", "New Password and Confirm Password should be same");
    }
    else {
      System.out.println(password.getNewPassword());
  
      changePasswordService.updatePassword(user,newPassword);
      mav = new ModelAndView("login");
      mav.addObject("message", "Password change successful");
    }
    return mav;

}
}
