package com.virtusa.payroll.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;

@Repository
public class UpadateProfileDaoImpl implements UpdateProfileDao{

	@Autowired
	SessionFactory sessionFactory;

	public Employee getEmployeeById(int empid) {
		// TODO Auto-generated method stub
		return (Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
	}
	public Address getAddressById(int empid) {
		return (Address) sessionFactory.getCurrentSession().get(Address.class, empid);
	}
	
	public void updateEmployeeInfo(Employee e) {
		 sessionFactory.getCurrentSession().update(e);	
	}
    public void updateAddress(Address a) {
		  sessionFactory.getCurrentSession().update(a);
	}

}
