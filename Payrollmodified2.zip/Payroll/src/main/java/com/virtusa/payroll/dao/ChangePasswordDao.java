package com.virtusa.payroll.dao;

import java.util.List;

import com.virtusa.payroll.model.User;

public interface ChangePasswordDao {
	

	public User getUserById(int empid);
	
	public List<User> listUsers();

	public void updatePassword(User user, String newPassword);

}
