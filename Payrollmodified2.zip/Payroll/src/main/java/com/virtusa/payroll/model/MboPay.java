package com.virtusa.payroll.model;

public class MboPay {

	private int year;
	private String quarter;
	public MboPay() {
		// TODO Auto-generated constructor stub
	}
	public MboPay(int year, String quarter) {
		this.year = year;
		this.quarter = quarter;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	
	
}
