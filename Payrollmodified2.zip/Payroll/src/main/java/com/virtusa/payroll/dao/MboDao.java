package com.virtusa.payroll.dao;

import com.virtusa.payroll.model.Employee;

public interface MboDao {
	
	public int MBOPayout(int empid);
	public Employee getUserById(int empid);		
	public float getMBO(int year,String quarter,int eid);

}
