package com.virtusa.payroll.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.MboDao;

import com.virtusa.payroll.model.Employee;

@Service
@Transactional
public class MboPayoutServiceImpl implements MboPayoutService{
	
	@Autowired
	MboDao mboDao;
	
	
	public void setMboDao(MboDao mboDao) {
		this.mboDao =  mboDao;
	}

	@Transactional
	public int MBOPayout(int empid)
	{
		return mboDao.MBOPayout(empid);
	
	}
	@Transactional
	public Employee getUserById(int empid) {
		return mboDao.getUserById(empid);
	
	}
	@Transactional
	public float getMBO(int year,String quarter,int eid) {
	
		return mboDao.getMBO(year, quarter, eid);
	}
}
