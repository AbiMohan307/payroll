package com.virtusa.payroll.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.User;
import com.virtusa.payroll.service.LoginService;

@Controller
@SessionAttributes("empid")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView showLogin(HttpServletRequest request,HttpServletResponse response)
	{
		
		ModelAndView mav=new ModelAndView("login");
		mav.addObject("login" ,new User());
		
		return mav;
		
	}
	
	
	
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpSession session,
		     @Valid @ModelAttribute User login,BindingResult br)
{
		
		ModelAndView mav=new ModelAndView();
		 
		if(br.hasErrors())
		{
			mav.setViewName("login");
		
		}
		else
		{
	    int log = loginService.validateEmployee(login);

	    if (log!=0) {
	      mav = new ModelAndView("frame");
	      mav.addObject("empid",login.getEmployee_id());
	        } 
	    else {
	      mav = new ModelAndView("login");
	      mav.addObject("message", "Username or Password is wrong!!");
	    }
		}
	    return mav;
	  }
	

}
