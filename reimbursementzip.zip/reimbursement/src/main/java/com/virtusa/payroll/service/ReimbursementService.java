package com.virtusa.payroll.service;

import java.util.List;

import com.virtusa.payroll.models.Reimbursement;

public interface ReimbursementService {

	public List<Reimbursement> getdetails(String empid);
}
