package com.virtusa.payroll.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reimbursement")
public class Reimbursement {

	@Id
	@Column
	String emp_id;
	@Column
	String pay_component;
	@Column
	float annual_plan;
	@Column
	float available_amount;
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getPay_component() {
		return pay_component;
	}
	public void setPay_component(String pay_component) {
		this.pay_component = pay_component;
	}
	public float getAnnual_plan() {
		return annual_plan;
	}
	public void setAnnual_plan(float annual_plan) {
		this.annual_plan = annual_plan;
	}
	public float getAvailable_amount() {
		return available_amount;
	}
	public void setAvailable_amount(float available_amount) {
		this.available_amount = available_amount;
	}
	public Reimbursement() {
		// TODO Auto-generated constructor stub
	}
	public Reimbursement(String emp_id, String pay_component, float annual_plan, float available_amount) {
		this.emp_id = emp_id;
		this.pay_component = pay_component;
		this.annual_plan = annual_plan;
		this.available_amount = available_amount;
	}
	
	
}
