package com.virtusa.payroll.dao;

import java.util.List;

import com.virtusa.payroll.models.Reimbursement;

public interface ReimbursementDao {
	
	public List<Reimbursement> getdetails(String empid);

}
