package com.virtusa.payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.models.Reimbursement;
import com.virtusa.payroll.service.ReimbursementService;

@Controller
public class ReimbursementController {
	
	@Autowired
	ReimbursementService reimbursementService; 
	
		@RequestMapping(value="/claim",method = RequestMethod.GET)
		public ModelAndView claims() {
			
			ModelAndView mav = new ModelAndView();
			
			List<Reimbursement> reimbursement = reimbursementService.getdetails("1");
			
			System.out.println(reimbursement.size());
			
			mav.addObject("claim", reimbursement);
			
			mav.setViewName("reimbursement");
			return mav;
			
			
		}
		
		
		@RequestMapping(value="/claimReim",method = RequestMethod.POST)
		public ModelAndView claimRe() {
			System.out.println("reimbursement Controller");
			return new ModelAndView("index");
		}
			

}
