package com.virtusa.payroll.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.models.Reimbursement;

@Repository
public class ReimbursementDaoimpl implements ReimbursementDao {

	@Autowired
	SessionFactory sessionfactory;
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Reimbursement> getdetails(String empid) {
		Query query = sessionfactory.getCurrentSession().createQuery("from Reimbursement r where r.emp_id = :empid");
		query.setParameter("empid", empid);
		
		return query.list();
	}

}
