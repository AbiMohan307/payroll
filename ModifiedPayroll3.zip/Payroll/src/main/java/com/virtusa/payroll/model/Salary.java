package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salary")
public class Salary {
	
	@Id
	@Column
	String e_id;
	@Column
	float ctc;
	@Column
	int designation_id;
	public String getE_id() {
		return e_id;
	}
	public void setE_id(String e_id) {
		this.e_id = e_id;
	}
	public float getCtc() {
		return ctc;
	}
	public void setCtc(float ctc) {
		this.ctc = ctc;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public Salary() {
		// TODO Auto-generated constructor stub
	}
	public Salary(String e_id, float ctc, int designation_id) {
		this.e_id = e_id;
		this.ctc = ctc;
		this.designation_id = designation_id;
	}
	@Override
	public String toString() {
		return "Salary [e_id=" + e_id + ", ctc=" + ctc + ", designation_id=" + designation_id + "]";
	}
	

}
