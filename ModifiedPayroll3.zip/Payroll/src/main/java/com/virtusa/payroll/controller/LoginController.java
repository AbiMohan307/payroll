package com.virtusa.payroll.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.User;
import com.virtusa.payroll.service.LoginService;


@Controller

public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	
	
	
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView showLogin(HttpServletRequest request,HttpServletResponse response)
	{
		ModelAndView mav=new ModelAndView("login");
		mav.addObject("login" ,new User());			
		return mav;
		
		
	}
	
	
	
	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public ModelAndView loginProcess(HttpSession session,
		   @ModelAttribute("login") User login)
	{
		
		
		ModelAndView mav=new ModelAndView();
		 
   	 
	    int log = loginService.validateEmployee(login);
	    
	   
	    if (log!=0) {
	    	if(log==1)
	    	{
	      mav = new ModelAndView("welcome");
	      mav.addObject("empid",login.getEmployee_id());
	      mav.addObject("message", "welcome");
	        } 
	    	else {
	    		 mav = new ModelAndView("frame");
	   	      mav.addObject("empid",login.getEmployee_id());
	    	}
	    }
	    	else {
	      mav = new ModelAndView("login");
	      mav.addObject("message", "Username or Password is wrong!!");
	    }
		
	    return mav;
		 
		}
		
	  
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	  public String logout(HttpSession session)
		{
		
		
			session.invalidate();
			return "redirect:/";
		}
		

}
