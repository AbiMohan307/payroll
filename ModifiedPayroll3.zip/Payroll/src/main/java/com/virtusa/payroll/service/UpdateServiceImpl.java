package com.virtusa.payroll.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.UpdateDAO;
import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;

@Service
@Transactional
public class UpdateServiceImpl implements UpdateService{
	@Autowired
	UpdateDAO updateDAO;
	
	@Transactional
	public Employee getEmployeeById(String empid) {
		return updateDAO.getEmployeeById(empid);
	}
	@Transactional
	public Address getAddressById(String empid) {
		// TODO Auto-generated method stub
		return updateDAO.getAddressById(empid);
	}
	@Transactional
	public void updateAddress(Address a) {
		 updateDAO.updateAddress(a);
		
	}
	@Transactional
	public void updateEmployeeInfo(Employee e) {
		 updateDAO.updateEmployeeInfo(e);
		
	}

	
	
}
