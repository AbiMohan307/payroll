package com.virtusa.payroll.dao;

import java.util.List;

import com.virtusa.payroll.model.Reimbursement;



public interface ReimbursementDao {
	
	public List<Reimbursement> getdetails(String empid);

	public List<Reimbursement> getClaimDetails(String empid, String claimType);

	public void updateClaim(Reimbursement reim);

}
