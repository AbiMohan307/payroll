package com.virtusa.payroll.dao;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Salary;

@Repository
public class AdminDaoImpl implements AdminDao{

	@Autowired
	SessionFactory sessionFactory;
	
	
	public void remove(Employee e) {
		sessionFactory.getCurrentSession().delete(e);
	}

	public void addAddressInfo(Address a) {
		 sessionFactory.getCurrentSession().save(a);
		
	}

	public void addEmployeeInfo(Employee e) {
		 sessionFactory.getCurrentSession().save(e);
		
	}

	public void addRating(Rating rating) {
		sessionFactory.getCurrentSession().save(rating);		
	}

	public void remove(Employee e, Address a, Salary s, String emp_id) {
		
		sessionFactory.getCurrentSession().delete(a);
		sessionFactory.getCurrentSession().delete(s);
		Query query = sessionFactory.getCurrentSession().createQuery("delete from Rating r where emp_id = :empid");
		query.setParameter("empid", emp_id);
		int delete = query.executeUpdate();
		query = sessionFactory.getCurrentSession().createQuery("delete from Attendance a where emp_id = :empid");
		query.setParameter("empid", emp_id);
		delete = query.executeUpdate();
		sessionFactory.getCurrentSession().delete(e);
	}

	
}
