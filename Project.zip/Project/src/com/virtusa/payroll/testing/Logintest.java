package com.virtusa.payroll.testing;
import  org.junit.Assert;
import org.junit.Test;

import com.virtusa.payroll.dao.LoginDAO;
import com.virtusa.payroll.models.Login;

public class Logintest {
	@Test
	public void checkLogin() {
	//LoginDAO test = new LoginDAO();
	Login l1 = LoginDAO.login1(2, "Abi@02");
	 Login l2 = LoginDAO.login2(2);
	Assert.assertEquals(l1.getName(), l2.getName());
	Assert.assertEquals(l1.getPassword(), l2.getPassword());
}
}
