package com.virtusa.payroll.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletResponse;

import com.virtusa.payroll.models.Login;
import com.virtusa.payroll.models.ValidatePassword;
import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;

public class LoginDAO {
	public static String getQuestion(int empid) {
		 String questioninDB = null;
		try {
			 String query = SqlQuery.query;
				Connection con = DBUtils.buildConnection();
				PreparedStatement ps = con.prepareStatement(query);
				ps.setInt(1, empid);
				ResultSet res = ps.executeQuery();
			while(res.next()) {
				  questioninDB = res.getString(2);
			}
	}
		catch(Exception e) {
			e.printStackTrace();
		}
		return questioninDB;
	}
	public static String validateAnswer(int empid)
	{
		String answerinDB=null;
		try {
			String query =  SqlQuery.query;
			Connection con = DBUtils.buildConnection();
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, empid);
			ResultSet res = ps.executeQuery();
			
		while(res.next()) {
			  answerinDB=res.getString(3);
		}
			
		}catch(Exception e) {
			System.out.println(e);
	}
		return answerinDB;
	}
	public static int login(int empid,String Password) {
		int count = 0;
		try {
			String login_query = SqlQuery.login_query;
			Connection con = DBUtils.buildConnection();
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(login_query);
			ps.setInt(1, empid);
			ps.setString(2, Password);
			ResultSet res = ps.executeQuery();
			if(res.next()){
				 count = 1;
		   }
			}catch(Exception e) {
			System.out.println(e);
		}
		
		return count;
		
	}
	public static Login login1(int empid,String Password) {
		Login l = null;
		try {
			String login_query = SqlQuery.login_query;
			Connection con = DBUtils.buildConnection();
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(login_query);
			ps.setInt(1, empid);
			ps.setString(2, Password);
			ResultSet res = ps.executeQuery();
			if(res.next()){
				l = new Login(res.getInt(1),res.getString(2));
		   }
			}catch(Exception e) {
			System.out.println(e);
		}
		
		return l;
		
	}
	public static Login login2(int empid) {
		Login l = null;
		try {
			String login_query = SqlQuery.log_query;
			Connection con = DBUtils.buildConnection();
			System.out.println(con);
			PreparedStatement ps = con.prepareStatement(login_query);
			ps.setInt(1, empid);
			ResultSet res = ps.executeQuery();
			if(res.next()){
				 l = new Login(res.getInt(1),res.getString(2));
		   }
			}catch(Exception e) {
			System.out.println(e);
		}
		return l;
		
	}
	public static String update(int empid, String newPassword, String confirmPassword) throws IOException {
		int res = 0;
		String result = ValidatePassword.validate(newPassword);
		System.out.println(result);	
		try {
			Connection conn = DBUtils.buildConnection();
			  
			if(result.isEmpty()) {
	         if(newPassword.equals(confirmPassword)){
	        	 String update_query = SqlQuery.update_query;
	        	 PreparedStatement pst1=conn.prepareStatement(update_query);
		         pst1.setString(1, newPassword);
		         pst1.setInt(2, empid);
		         res =  pst1.executeUpdate();
	         if(res == 0) {
	        	 result = "New Password and Confirm password are not matching";
	         }
	      }
		}
	    }
	     catch (Exception e) {
	 			e.printStackTrace();
	 		}return result;
		
	}
}
