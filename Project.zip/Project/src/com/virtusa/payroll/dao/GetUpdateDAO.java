package com.virtusa.payroll.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.payroll.models.Address;
import com.virtusa.payroll.models.Designation;
import com.virtusa.payroll.models.Employee;
import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;

public class GetUpdateDAO {
	
	public static Employee displayDetails(int empid) throws SQLException
	{
		
		Connection  con=DBUtils.buildConnection();
    String empname_query=SqlQuery.empname_query;
    PreparedStatement ps1=con.prepareStatement(empname_query);
    ps1.setInt(1,empid);
    Employee employee=null;
    ResultSet rs1=ps1.executeQuery();
    String displayEmpName=null,email_id=null,contactno=null;
    float experience=0;
    while(rs1.next()) {
    	displayEmpName=rs1.getString(1);
    	email_id=rs1.getString(2);
    	contactno=rs1.getString(3);
    	experience=rs1.getFloat(4);
    	employee=new Employee(displayEmpName,  email_id, contactno, experience);
    }
	return employee; 
    
          	
	}
	public static Designation getDesigantion(int empid) throws SQLException
	{
		Connection  con=DBUtils.buildConnection();
		Designation des=null;
		String designation_query=SqlQuery.designation_query;
	    PreparedStatement ps3=con.prepareStatement(designation_query);
	    ps3.setInt(1,empid);
	    ResultSet rs3=ps3.executeQuery();
	    String designation=null;
	    while(rs3.next()) {
	    	designation=rs3.getString(1);
	    	des=new Designation(designation);
	    }
		return des;
	}
	public static Address getAddress(int empid) throws SQLException 
	{
		Address add=null;
		Connection  con=DBUtils.buildConnection();
		 String address_query=SqlQuery.address_query;
		    PreparedStatement ps5=con.prepareStatement(address_query);
		    ps5.setInt(1,empid);
		    ResultSet rs5=ps5.executeQuery();
		    String address=null;
		    while(rs5.next()) {
		    	address=rs5.getString(1);
		    	add=new Address(address);
		    }
		return add;
		
	}
}
    


