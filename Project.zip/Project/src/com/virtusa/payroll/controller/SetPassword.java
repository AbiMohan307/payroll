package com.virtusa.payroll.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.SetPasswordDAO;
import com.virtusa.payroll.models.ValidatePassword;



@WebServlet("/SetPassword")
public class SetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();                                      
			 
		HttpSession session=request.getSession(false);
		int empid=(int) session.getAttribute("eid");
		
		System.out.println(empid);
		//int empid=1;
		String oldPassword=request.getParameter("old");
		String newPassword=request.getParameter("new");
		String confirmPassword=request.getParameter("confirm");		 
		 RequestDispatcher dispatcher = null;
		 String result = ValidatePassword.validate(newPassword);
		 String passwordInDB=null;
		 if(result.isEmpty()) 
			{
			 passwordInDB=SetPasswordDAO.getPassword(newPassword,empid);
			
	         if(passwordInDB.equals(oldPassword) && newPassword.equals(confirmPassword))
	         {
	        	 int val=SetPasswordDAO.updatePassword(newPassword, empid);
	        	 if(val==1)
	        	 {
		         out.println("Password changed success");
		        dispatcher = request.getRequestDispatcher("setPassword.html");
		        dispatcher.include(request, response);
	        	 }
		         
	         }
	    	  else if(!newPassword.equals(confirmPassword)) {
	    			  out.println("New password not matching with confirm password");
	    			  dispatcher = request.getRequestDispatcher("setPassword.html");
	  		        dispatcher.include(request, response);
	    		  }
			else 
			{
				out.println("Entered password not matching with old password");
				 dispatcher = request.getRequestDispatcher("setPassword.html");
	  		        dispatcher.include(request, response);
			}
			}
			else {
				out.println(result);
				dispatcher = request.getRequestDispatcher("setPassword.html");
  		        dispatcher.include(request, response);
			}
		
	}
}