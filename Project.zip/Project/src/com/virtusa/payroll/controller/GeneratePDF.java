package com.virtusa.payroll.controller;



import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.virtusa.payroll.dao.SalaryDAO;
import com.virtusa.payroll.models.Salary;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class GeneratePDF
 */
@WebServlet("/GeneratePDF")
public class GeneratePDF extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Font TIME_ROMAN = new Font(Font.FontFamily.TIMES_ROMAN, 18,Font.BOLD);
	private static Font TIME_ROMAN_SMALL = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

	/**
	 * @param args
	 */
	public static Document createPDF(String file) {

		Document document = null;

		try {
			document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(file));
			document.open();

			

			addTitlePage(document);

			createTable(document);

			document.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return document;

	}

	private static void addTitlePage(Document document)
			throws DocumentException {

		Paragraph preface = new Paragraph();
		creteEmptyLine(preface, 1);
		preface.add(new Paragraph("Payslip", TIME_ROMAN));

		creteEmptyLine(preface, 1);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		preface.add(new Paragraph("Report created on "
				+ simpleDateFormat.format(new Date()), TIME_ROMAN_SMALL));
		document.add(preface);

	}

	private static void creteEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}
	static String pf1,insurance1,per_hour_salary1,hours_worked1, basicpay1,allowance1;
	public static void getVAlues(float pf,float insurance,float per_hour_salary,float hours_worked,float basicpay,float allowance)
	{
		 pf1=""+pf;
		 insurance1=""+insurance;
		 per_hour_salary1=""+per_hour_salary;
		 hours_worked1=""+hours_worked;
		 basicpay1= ""+basicpay;
		 allowance1=""+allowance;
	}

	private static void createTable(Document document) throws DocumentException {		
		Paragraph paragraph = new Paragraph();
		creteEmptyLine(paragraph, 2);
		document.add(paragraph);
		PdfPTable table = new PdfPTable(2);
		
		PdfPCell c1 = new PdfPCell(new Phrase("Earnings"));
		PdfPCell c2 = new PdfPCell(new Phrase("Amount"));
		
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);
		table.addCell(c2);
		
		
			table.setWidthPercentage(100);
			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			table.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			table.addCell("PF");
			table.addCell(pf1);
			table.addCell("Insurance");
			table.addCell(insurance1);
			table.addCell("Allowance");
			table.addCell(allowance1);
			table.addCell("Hours worked");
			table.addCell(hours_worked1);
			table.addCell("Basic pay");
			table.addCell(basicpay1);
		

		document.add(table);
	}

}
