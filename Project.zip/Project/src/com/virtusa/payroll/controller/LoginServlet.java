package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.payroll.dao.adminDAO;
import com.virtusa.payroll.models.Login;
import com.virtusa.payroll.service.DBUtils;




/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		String pwd=request.getParameter("pwd");
		
		Login login=adminDAO.createEmployee(id);
		if(id==login.getName()&&pwd.equals(login.getPassword()))
		{
			out.println("Welcome Admin!!"+"+<br>");
			RequestDispatcher rd=request.getRequestDispatcher("/Link.html");
			rd.include(request,response);
			
		}
		else
		{
			out.println("Admin id and password doesnot match");
			RequestDispatcher rd=request.getRequestDispatcher("/admin.html");
			rd.include(request,response);
		}
		
	}
	}


