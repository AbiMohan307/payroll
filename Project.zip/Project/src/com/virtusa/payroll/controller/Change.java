package com.virtusa.payroll.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.ChangeDAO;

/**
 * Servlet implementation class Change
 */
@WebServlet("/Change")
public class Change extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Change() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
	    
        HttpSession session=request.getSession(false);
		int empid=(int) session.getAttribute("eid");
  
        String email = request.getParameter("email_id");
        String mobile = request.getParameter("mobile_no");
        String address = request.getParameter("address");
        
      if(!email.isEmpty()) {
      	   
        	ChangeDAO.setEmailDetailsIfNotEmpty(email,empid);
      }
      else {
    	   

    	  String passEmail=ChangeDAO.setEmailDetailsIfEmpty(empid);
    	  ChangeDAO.setEmailDetailsIfNotEmpty(passEmail,empid);
      }
        
      if(!mobile.isEmpty()) {
        	ChangeDAO.setContactDetailsIfNotEmpty(mobile, empid);
        }
        else {
        	String passMobile=ChangeDAO.setContactDetailsIfEmpty(empid);
        	ChangeDAO.setContactDetailsIfNotEmpty(passMobile, empid);
        }
       
       if(!address.isEmpty()) {
        	ChangeDAO.setAddressDetailsIfNotEmpty(address,empid);
        }
        else {
        	String passAddress=ChangeDAO.setAddressDetailsIfEmpty(empid);
        	ChangeDAO.setAddressDetailsIfNotEmpty(passAddress,empid);
        }
       
      //response.sendRedirect("Update");
	
		 RequestDispatcher rd=request.getRequestDispatcher("Update");
		 rd.forward(request, response);
		 
		 }
}
