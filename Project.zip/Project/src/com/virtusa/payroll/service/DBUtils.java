package com.virtusa.payroll.service;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {
	public static Connection buildConnection() {
		//String driverName="com.mysql.cj.jdbc.Driver";
		String Url="jdbc:mysql://localhost/payroll";
		String uid="root",pid="mysql";
		
			try {
				Class.forName("com.mysql.jdbc.Driver").newInstance();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Connection conn=null;
			try {
				conn = DriverManager.getConnection(Url,uid,pid);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//System.out.println(conn);
		return conn;
	
	}
}
 