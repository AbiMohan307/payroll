package com.virtusa.payroll.sql;

public class SqlQuery {
	
		public static String sql="update employee set email_id=? where emp_id=?";
		public static String email_query="select email_id from employee where emp_id=?";
		public static String sql1="update employee set contact_number=? where emp_id=?";
		public static String contactno_query="select contact_number from employee where emp_id=?";
		public static String sql2="update address set address=? where emp_id=?";
		public static String address_query="select address from address where emp_id=?";
		public static String empname_query=
		    	"select emp_name,email_id,contact_number,experience from employee where emp_id=?";
		public static String designation_query="select designation_name from designation where designation_id="
	    		+ "(select designationid from salary where empid=?)";
		public static String query = "select * from forgot_password where employeeid = ?";
		public static String login_query = "select * from login where employee_id = ? and password=?";
		public static String log_query = "select * from login where employee_id = ?";
		 public static String update_query = "update login set password=? where employee_id=?";
		 public static String mbo1_query = "select mbo1 from mbo where e_id=? and year=?";
		 public static String mbo2_query = "select mbo2 from mbo where e_id=? and year=?";
		 public static String mbo3_query = "select mbo3 from mbo where e_id=? and year=?";
		 public static String mbo4_query = "select mbo4 from mbo where e_id=? and year=?";
		 public static String date_query = "select joining_date from employee where emp_id=?";
		 public static String salary_query="select * from salary where empid=? and year=? and month=?";
		 public static String query1 = "select password from login where employee_id = ?";
		 public static String query2 = "update login set password=? where employee_id=?";
		 public static  String delemp="delete from employee where emp_id=?";
		 public static String deladd="delete from address where emp_id=?";
		 public static String delsal="delete from salary where empid=?";
		 public static String dellog="delete from login where employee_id=?";
		 public static String delpwd="delete from forgot_password where employeeid=?";
		 public static String admin_login="select * from admin where admin_id=?";
		 public static String empquery="insert into employee(emp_id,emp_name,email_id,contact_number,joining_date,hr_id,dept_id,manager_id,experience) values(?,?,?,?,?,?,?,?,?)";
		 public static String addquery="insert into address(address,city_id,state_id,pincode,emp_id) values(?,?,?,?,?)";
}
