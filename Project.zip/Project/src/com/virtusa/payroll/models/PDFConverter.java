package com.virtusa.payroll.models;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.virtusa.payroll.controller.GeneratePDF;
import com.virtusa.payroll.dao.SalaryDAO;

/**
 * Servlet implementation class PDFConverter
 */
@WebServlet("/PDFConverter")
public class PDFConverter extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 
	 @SuppressWarnings("resource")
	protected void doGet(HttpServletRequest request,
	            HttpServletResponse response) throws ServletException, IOException {
		 				 
	    final ServletContext servletContext = request.getSession()
	            .getServletContext();
	    final File tempDirectory = (File) servletContext
	            .getAttribute("javax.servlet.context.tempdir");
	    final String temperotyFilePath = tempDirectory.getAbsolutePath();

	    String fileName = "Generate_Report_"+System.currentTimeMillis()+".pdf";
	    response.setContentType("application/pdf");
	    response.setHeader("Cache-Control", "no-cache");
	    response.setHeader("Cache-Control", "max-age=0");
	    response.setHeader("Content-disposition", "attachment; " +
	            "filename="+ fileName);
				
	    try {

	        GeneratePDF.createPDF(temperotyFilePath+"\\"+fileName);
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        baos = convertPDFToByteArrayOutputStream(
	                temperotyFilePath+"\\"+fileName);
	        OutputStream os = response.getOutputStream();
	        baos.writeTo(os);
	        os.flush();
	    } catch (Exception e1) {
	        e1.printStackTrace();
	    }
	    }

	    protected void doPost(HttpServletRequest request,HttpServletResponse 
	            response) throws ServletException, IOException {     
	    	doGet(request,response);
	    }

	    private static ByteArrayOutputStream 
	        convertPDFToByteArrayOutputStream(String fileName) {

	        InputStream inputStream = null;
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        try {

	            inputStream = new FileInputStream(fileName);

	            byte[] buffer = new byte[1024];
	            baos = new ByteArrayOutputStream();

	            int bytesRead;
	            while ((bytesRead = inputStream.read(buffer)) != -1) {
	                baos.write(buffer, 0, bytesRead);
	            }

	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (inputStream != null) {
	                try {
	                    inputStream.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	        return baos;
	    }

}
