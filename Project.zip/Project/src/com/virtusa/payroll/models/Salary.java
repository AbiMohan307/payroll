package com.virtusa.payroll.models;

public class Salary {
	int salary_id,designation_id,emp_id;
	float pf,allowance,insurance,per_hour_salary,hours_worked;
	public int getSalary_id() {
		return salary_id;
	}
	public void setSalary_id(int salary_id) {
		this.salary_id = salary_id;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public float getPf() {
		return pf;
	}
	public void setPf(float pf) {
		this.pf = pf;
	}
	public float getAllowance() {
		return allowance;
	}
	public void setAllowance(float allowance) {
		this.allowance = allowance;
	}
	public float getInsurance() {
		return insurance;
	}
	public void setInsurance(float insurance) {
		this.insurance = insurance;
	}
	public float getPer_hour_salary() {
		return per_hour_salary;
	}
	public void setPer_hour_salary(float per_hour_salary) {
		this.per_hour_salary = per_hour_salary;
	}
	public float getHours_worked() {
		return hours_worked;
	}
	public void setHours_worked(float hours_worked) {
		this.hours_worked = hours_worked;
	}
	
	public Salary() {
		// TODO Auto-generated constructor stub
		
	}
	public Salary(int salary_id, int designation_id, int emp_id, float pf,
			float allowance, float insurance, float per_hour_salary,
			float hours_worked) {
		super();
		this.salary_id = salary_id;
		this.designation_id = designation_id;
		this.emp_id = emp_id;
		this.pf = pf;
		this.allowance = allowance;
		this.insurance = insurance;
		this.per_hour_salary = per_hour_salary;
		this.hours_worked = hours_worked;
	}
	@Override
	public String toString() {
		return "Employee [salary_id=" + salary_id + ", designation_id="
				+ designation_id + ", emp_id=" + emp_id + ", pf=" + pf
				+ ", allowance=" + allowance + ", insurance=" + insurance
				+ ", per_hour_salary=" + per_hour_salary + ", hours_worked="
				+ hours_worked + "]";
	}
	
	

}
