package com.virtusa.payroll.models;

public class Designation {

	String designation;

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Designation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Designation(String designation) {
		super();
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Designation [designation=" + designation + "]";
	}
	
}
