package com.virtusa.payroll.models;

public  class ValidatePassword {
public static String validate(String newPassword) {
	int numCount = 0;
	int capCount= 0;
	int speCount=0;
	String result = "";
	String result1 = "";
	String result2= "";
	String result3 = "";
	String result4 = "";
	String nPassword=newPassword;
		  
	if (nPassword.length() < 4){									// Checks that password is long enough
		result1 = "Password is Too Short!";
		System.out.println(result1);	
    }
   else {
		   for (int x =0; x < nPassword.length(); x++) {
				
				  if(nPassword.charAt(x) >= 33 && nPassword.charAt(x) <= 47 || nPassword.charAt(x) >= 58 && nPassword.charAt(x) <= 64) { speCount ++; }
				 
			   if ((nPassword.charAt(x) > 47 && nPassword.charAt(x) < 58)) {			// Counts the number of numbers
					 numCount ++;
				}
	
				 if ((nPassword.charAt(x) > 64 && nPassword.charAt(x) < 91)) {			// Counts the number of capital letters
					capCount ++;
				}
		   }


			
			  if(speCount < 1) { result2 = "Not enough special charecters"; }
			 
			
			if (numCount < 1){									// Checks that password contains one numbers
				result3 = "Not Enough Numbers in Password!";
			} 
			
			if (capCount< 1) {									// Checks that password contains one capital letters
				result4 = "Not Enough Capital Letters in Password!";
			}
			
			
           
			
 }
	result =result1+result2+result3+result4;
	System.out.println("1"+result);
	return result;
}
}
