package com.virtusa.payroll.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.MboPayoutDao;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Salary;


@Service
@Transactional
public class MboPayoutServiceImpl implements MboPayoutService{ 


	@Autowired
	MboPayoutDao mboDao;
	
	
	public void setMboDao(MboPayoutDao mboDao) {
		this.mboDao = mboDao;
	}

	@Transactional
	public Employee getEmployeeDetails(String empid)
	{
		return mboDao.getEmployeeDetails(empid);
	
	}
	@Transactional
	public Salary getSalaryDetails(String empid) {
		return mboDao.getSalaryDetails(empid);
	
	}
	@Transactional
	public List<Rating> getRatingDetails(String empid, int year) {
	
		return mboDao.getRatingDetails(empid,year);
	}
}
