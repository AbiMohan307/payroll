package com.virtusa.payroll.view;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.virtusa.payroll.model.Mbo;


public class MboGeneratePDF extends AbstractPdfView {
	
	@Override
	protected void buildPdfDocument(Map<String, Object> map, Document document, PdfWriter pdfWriter, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		Mbo pdf = (Mbo) map.get("pdfGenerator");
		
		PdfPTable table = new PdfPTable(2);
       table.setWidths(new int[]{40, 60});

        table.addCell("Employee Id");
        table.addCell(pdf.getEmp_id());
        table.addCell("Employee Name");
        table.addCell(pdf.getEmp_name());
        table.addCell("Designamtion Id");
        table.addCell(Integer.toString(pdf.getDesignation_id()));
        table.addCell("CTC");
        table.addCell(Float.toString(pdf.getCtc()));
        table.addCell("Eligible Variable pay");
        table.addCell(Float.toString(pdf.getEligible_pay()));
        table.addCell("Previous rating");
        table.addCell(Integer.toString(pdf.getYear()));
        table.addCell("Current rating");
        table.addCell(Integer.toString(pdf.getRating()));
        table.addCell("Variable Pay");
        table.addCell(Float.toString(pdf.getVariable_pay()));
        
        document.add(table);
	}

	

}
