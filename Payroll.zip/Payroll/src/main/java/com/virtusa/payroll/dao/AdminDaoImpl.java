package com.virtusa.payroll.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;

@Repository
public class AdminDaoImpl implements AdminDao{

	@Autowired
	SessionFactory sessionFactory;
	
	
	public void remove(Employee e) {
		sessionFactory.getCurrentSession().delete(e);
	}

	public void addAddressInfo(Address a) {
		 sessionFactory.getCurrentSession().save(a);
		
	}

	public void addEmployeeInfo(Employee e) {
		 sessionFactory.getCurrentSession().save(e);
		
	}

	public void addRating(Rating rating) {
		sessionFactory.getCurrentSession().save(rating);		
	}
}
