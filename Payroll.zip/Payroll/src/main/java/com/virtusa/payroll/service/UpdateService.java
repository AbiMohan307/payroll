package com.virtusa.payroll.service;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;

public interface UpdateService {	

	public Employee getEmployeeById(String empid);
	public Address getAddressById(String empid);
	

	public void updateAddress(Address a);
	public void updateEmployeeInfo(Employee e);
}
