package com.virtusa.payroll.model;

import java.sql.Date;



public class Payslip {

	String empid;
	String emp_name;
	String location;
	String designation;
	//Date dob;
	String gender;
	//Date joining_date;
	float basic;
	float yearly_basic;
	float pf;
	float yearly_pf;
	float HRA;
	float yearly_HRA;
	float ESI;
	float y_ESI;
	public Payslip(String empid, String emp_name, String location, String designation, String gender, float basic,
			float yearly_basic, float pf, float yearly_pf, float hRA, float yearly_HRA, float eSI, float y_ESI) {
		super();
		this.empid = empid;
		this.emp_name = emp_name;
		this.location = location;
		this.designation = designation;
		this.gender = gender;
		this.basic = basic;
		this.yearly_basic = yearly_basic;
		this.pf = pf;
		this.yearly_pf = yearly_pf;
		HRA = hRA;
		this.yearly_HRA = yearly_HRA;
		ESI = eSI;
		this.y_ESI = y_ESI;
	}
	
	public float getBasic() {
		return basic;
	}
	public void setBasic(float basic) {
		this.basic = basic;
	}
	public float getYearly_basic() {
		return yearly_basic;
	}
	public void setYearly_basic(float yearly_basic) {
		this.yearly_basic = yearly_basic;
	}
	public float getPf() {
		return pf;
	}
	public void setPf(float pf) {
		this.pf = pf;
	}
	public float getYearly_pf() {
		return yearly_pf;
	}
	public void setYearly_pf(float yearly_pf) {
		this.yearly_pf = yearly_pf;
	}
	public float getHRA() {
		return HRA;
	}
	public void setHRA(float hRA) {
		HRA = hRA;
	}
	public float getYearly_HRA() {
		return yearly_HRA;
	}
	public void setYearly_HRA(float yearly_HRA) {
		this.yearly_HRA = yearly_HRA;
	}
	public float getESI() {
		return ESI;
	}
	public void setESI(float eSI) {
		ESI = eSI;
	}
	public float getY_ESI() {
		return y_ESI;
	}
	public void setY_ESI(float y_ESI) {
		this.y_ESI = y_ESI;
	}
	public Payslip()
	{
		
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	/*public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}*/
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	/*public Date getJoining_date() {
		return joining_date;
	}
	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;*/
	//}
	/*public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}*/
}
