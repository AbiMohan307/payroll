package com.virtusa.payroll.dao;





import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Attendance;
import com.virtusa.payroll.model.Designation;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Salary;


@Repository
public class PaySlipDaoImpl implements PaySlipDao{
	
	@Autowired
	SessionFactory sessionFactory;
	public List<Salary> getSalary(String empid) {
		// TODO Auto-generated method stub
		Query query=sessionFactory.getCurrentSession().createQuery("from Salary s where s.e_id=:empid");
		query.setParameter("empid", empid);
		return query.list();
	}
	public List<Attendance> getHoursWorked(String empid, String month, int year) {
		// TODO Auto-generated method stub
		Query query=sessionFactory.getCurrentSession().createQuery(" from Attendance a where a.emp_id=:empid"
				+ " and a.month=:month"
				+ " and a.year=:year");
		query.setParameter("empid", empid);
		query.setParameter("month", month);
		query.setParameter("year", year);
		return query.list();
	}
	public List<Employee> getEmployee(String empid) {
		// TODO Auto-generated method stub
		Query query=sessionFactory.getCurrentSession().createQuery("from Employee e where e.emp_id=:empid");
		query.setParameter("empid", empid);
		return query.list();
	}
	public List<Designation> getDesignation(int designation_id) {
		// TODO Auto-generated method stub
		Query query=sessionFactory.getCurrentSession().createQuery("from Designation d where d.designation_id=:designation_id");
		query.setParameter("designation_id", designation_id);
		return query.list();
	}

}
