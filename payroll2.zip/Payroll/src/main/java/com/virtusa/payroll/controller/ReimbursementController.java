package com.virtusa.payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Reimbursement;
import com.virtusa.payroll.service.ReimbursementService;

@Controller
public class ReimbursementController {
	
	@Autowired
	ReimbursementService reimbursementService; 
	
		@RequestMapping(value="/claim",method = RequestMethod.GET)
		public ModelAndView claims() {
			
			ModelAndView mav = new ModelAndView();
			
			List<Reimbursement> reimb = reimbursementService.getdetails("1");
			
			for(int i=0;i<reimb.size();i++) {
			System.out.println(reimb.get(i).getPay_component());
			}
			mav.addObject("claim", reimb);
			
			mav.setViewName("reimbursement");
			return mav;
			
			
		}
		
		
		@RequestMapping(value="/claimReim",method = RequestMethod.POST)
		public String claimRe(ModelMap mav,@RequestParam("claimType")String claimType,@RequestParam("claimAmount") float claimAmount) {
			System.out.println(claimType+" "+claimAmount);
			
			List<Reimbursement> reimb = reimbursementService.getClaimDetails("1",claimType);
			
			Reimbursement reim = new Reimbursement(reimb.get(0).getEmp_id(),reimb.get(0).getPay_component(),reimb.get(0).getAnnual_plan(),reimb.get(0).getAvailable_amount());
			float amount = reim.getAvailable_amount()-claimAmount;
			
			if(amount ==0) {
				mav.addAttribute("message", "Request rejected!!! No available amount to claim");
			}
			else if(amount-claimAmount < 0) {
				mav.addAttribute("message", "Request rejected!!! Claiming Amount is exceeding available amount to claim");
			}
			else {
				mav.addAttribute("message", "Request Accepted!! You have successfully claimed for amount of "+claimAmount);
				reim.setAvailable_amount(amount); 
				reimbursementService.updateClaim(reim); 
			}
			mav.addAttribute("claimAmount", claimAmount);
			mav.addAttribute("reim", reim);
			return "reimbursementDisplay";
		
		}
}
