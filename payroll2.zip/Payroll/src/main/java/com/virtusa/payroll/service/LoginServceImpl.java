package com.virtusa.payroll.service;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.payroll.dao.LoginDao;
import com.virtusa.payroll.model.User;


@Service
@Transactional
public class LoginServceImpl implements LoginService{

	@Autowired
	LoginDao loginDao;
	public int validateEmployee(User login) {
		// TODO Auto-generated method stub
		
		return loginDao.validateEmployee(login);
	}

	public void setLoginDao(LoginDao loginDao)
	{
		this.loginDao=loginDao;
	}

	
	
}
