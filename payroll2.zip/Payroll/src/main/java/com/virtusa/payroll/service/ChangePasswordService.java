package com.virtusa.payroll.service;

import com.virtusa.payroll.model.Employee;

public interface ChangePasswordService {

		
	public Employee getEmployeeById(String empid);
	
	public void updatePassword(Employee employee);
}
