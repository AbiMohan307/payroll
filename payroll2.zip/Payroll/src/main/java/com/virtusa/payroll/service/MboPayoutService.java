package com.virtusa.payroll.service;

import java.util.List;


import com.virtusa.payroll.dao.MboPayoutDao;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Salary;


public interface MboPayoutService {
	
	
	public void setMboDao(MboPayoutDao mboDao); 
	
	public Employee getEmployeeDetails(String empid);
	
	public Salary getSalaryDetails(String empid); 
	
	public List<Rating> getRatingDetails(String empid, int year);
}
