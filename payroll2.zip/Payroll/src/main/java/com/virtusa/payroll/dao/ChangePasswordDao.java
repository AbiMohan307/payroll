package com.virtusa.payroll.dao;

import com.virtusa.payroll.model.Employee;

public interface ChangePasswordDao {
	

	public Employee getEmployeeById(String empid);

	public void updatePassword(Employee employee);

}
