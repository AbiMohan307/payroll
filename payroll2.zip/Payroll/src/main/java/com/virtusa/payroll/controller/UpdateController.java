
package com.virtusa.payroll.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;




import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.service.UpdateService;


@Controller
public class UpdateController {
	@Autowired
	UpdateService updateService;
	

	
	@RequestMapping(value = "/viewProfile", method = RequestMethod.GET)
	  public ModelAndView update(){
		ModelAndView mav = new ModelAndView("viewProfile");
		 String empid = "1";
		 Employee employee=updateService.getEmployeeById(empid);
		 Address address=updateService.getAddressById(empid);
		 mav.addObject("employee",employee);
		 mav.addObject("address",address);
		 return mav;
	}
	@RequestMapping(value = "/updateProfile", method = RequestMethod.GET)
	  public ModelAndView updateProfile(){
		ModelAndView mav = new ModelAndView();
		 String empid = "1";
		 Employee employee=updateService.getEmployeeById(empid);
		 Address address=updateService.getAddressById(empid);
		 System.out.println(employee.toString());
		 mav.addObject("employee",employee);
		 mav.addObject("address",address);
		mav.setViewName("updateProfile");
		return mav;
		
	}
	@RequestMapping(value = "/updateProcess", method = RequestMethod.POST)
	  public ModelAndView updateProcess(HttpServletRequest request, HttpServletResponse response,
			  @RequestParam(value = "email",defaultValue = "null") String email, 
			  @RequestParam(value = "mobile_no", defaultValue = "null") String mobile_no, 
			  @RequestParam(value = "door_no",defaultValue = "null") String door_no,
			  @RequestParam(value = "street",defaultValue = "null") String street,
			  @RequestParam(value = "city",defaultValue = "null") String city,
			  @RequestParam(value = "state",defaultValue = "null") String state,
			  @RequestParam(value = "pincode",defaultValue = "null") String pincode) {
	
	   ModelAndView mav = null;
	
	   	String empid = "1";
		 Employee employee=updateService.getEmployeeById(empid);
		 Address address=updateService.getAddressById(empid);
	    
	    if(!email.isEmpty()) {	
		      employee.setEmail(email);				
	          updateService.updateEmployeeInfo(employee);	 	
		}
	     if(!mobile_no.isEmpty()){
	    	employee.setMobile_no(mobile_no);
	 	    updateService.updateEmployeeInfo(employee);
	    }  
	     if(!door_no.isEmpty()) {
	        address.setDoor_no(door_no);
		    updateService.updateAddress(address);
		}
	     if(!street.isEmpty()) {
	        address.setStreet(street);
		    updateService.updateAddress(address);
		}
	     if(!city.isEmpty()) {
	        address.setCity(city);
		    updateService.updateAddress(address);
		}
	     if(!state.isEmpty()) {
	        address.setState(state);
		    updateService.updateAddress(address);
		}
	     if(!pincode.isEmpty()) {
	        address.setPincode(pincode);
		    updateService.updateAddress(address);
		}
	      mav = new ModelAndView("viewProfile");
	      mav.addObject("employee",employee);
	      mav.addObject("address",address);
	      mav.addObject("message", "Password change successful");
	      return mav;
	    }
	
	
}
