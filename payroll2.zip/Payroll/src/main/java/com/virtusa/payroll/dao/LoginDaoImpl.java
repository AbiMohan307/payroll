package com.virtusa.payroll.dao;



import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Admin;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.User;

@Repository
public class LoginDaoImpl implements LoginDao{

	@Autowired
	SessionFactory sessionFactory;
	public int validateEmployee(User login) {
		// TODO Auto-generated method stub
		if(login.getEmployee_id().equals("admin"))
		{
			Admin admin=(Admin)sessionFactory.getCurrentSession().get(Admin.class,login.getEmployee_id());
			if(login.getPassword().equals(admin.getPassword()))
			{
				return 1;
			}
			else
			{
			return 0;
			}
		}
		else
		{
			Employee log= (Employee) sessionFactory.getCurrentSession().get(Employee.class,login.getEmployee_id());
			
			if(login.getPassword().equals(log.getPassword()))
			{
				return 2;
			}
			else
			{
			return 0;
			}
		}
		
			}
	
}
