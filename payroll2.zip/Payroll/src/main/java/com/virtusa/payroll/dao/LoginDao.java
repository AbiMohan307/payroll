package com.virtusa.payroll.dao;



import com.virtusa.payroll.model.User;



public interface LoginDao {
	
	public int validateEmployee(User login);
	
	
}
