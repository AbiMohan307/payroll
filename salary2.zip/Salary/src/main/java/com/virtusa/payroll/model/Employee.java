package com.virtusa.payroll.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	@Column
	 String emp_id;
	@Column
	 String emp_name;
	@Column
	  String password;
	@Column
		String email;
	@Column 
	   String mobile_no;
	@Column
	   Date joining_date;
	@Column
	  int designation_id;
	@Column
	 int experience;
	@Column
		String location;
	@Column
		String gender;
	@Column
		Date DOB;
	Employee()
	{
		
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public Date getJoining_date() {
		return joining_date;
	}
	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public Employee(String emp_id, String emp_name, String password, String email, String mobile_no, Date joining_date,
			int designation_id, int experience, String location, String gender, Date dOB) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.password = password;
		this.email = email;
		this.mobile_no = mobile_no;
		this.joining_date = joining_date;
		this.designation_id = designation_id;
		this.experience = experience;
		this.location = location;
		this.gender = gender;
		DOB = dOB;
	}
	
}
