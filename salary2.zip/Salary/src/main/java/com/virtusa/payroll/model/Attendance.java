package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="attendance")
public class Attendance {

	@Id
	@Column
	String emp_id;
	@Column
	float hours_worked;
	@Column
	String month;
	@Column
	int year;
	Attendance()
	{
		
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public float getHours_worked() {
		return hours_worked;
	}
	public void setHours_worked(float hours_worked) {
		this.hours_worked = hours_worked;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public Attendance(String emp_id, float hours_worked, String month, int year) {
		super();
		this.emp_id = emp_id;
		this.hours_worked = hours_worked;
		this.month = month;
		this.year = year;
	}
	
}
