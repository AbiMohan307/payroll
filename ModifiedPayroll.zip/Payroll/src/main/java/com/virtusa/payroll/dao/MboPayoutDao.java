package com.virtusa.payroll.dao;

import java.util.List;

import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Salary;






public interface MboPayoutDao 
{		
	
	public Employee getEmployeeDetails(String empid);
	
	public Salary getSalaryDetails(String empid);
	
	public List<Rating> getRatingDetails(String empid, int year);
		
		

}
