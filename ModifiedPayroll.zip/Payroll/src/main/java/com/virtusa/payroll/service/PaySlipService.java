package com.virtusa.payroll.service;

import java.util.List;

import com.virtusa.payroll.model.Attendance;
import com.virtusa.payroll.model.Designation;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Salary;

public interface PaySlipService {
	
	public List<Attendance>  getHoursWorked(String empid,String month,int year);
	public List<Salary> getSalary(String empid);
	public List<Employee> getEmployee(String empid);
	public List<Designation> getDesignation(int designation_id);

}
