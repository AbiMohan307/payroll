package com.virtusa.payroll.model;

import java.sql.Date;

public class Register {

	String emp_id;
	String emp_name;
	String gender;
	String location;
	String DOB;
	String password;
	String email;
	String mobile_no;
	String joining_date;
    int designation_id;
	String door_no;
	String street;
	String city;
	String state;
	String pincode;
    float experience;
	
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public Register(String emp_id, String emp_name, String gender,
			String location, String dOB, String password, String email,
			String mobile_no, String joining_date, int designation_id,
			String door_no, String street, String city, String state,
			String pincode, float experience) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.gender = gender;
		this.location = location;
		DOB = dOB;
		this.password = password;
		this.email = email;
		this.mobile_no = mobile_no;
		this.joining_date = joining_date;
		this.designation_id = designation_id;
		this.door_no = door_no;
		this.street = street;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.experience = experience;
	}
	public Register() {
		// TODO Auto-generated constructor stub
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getJoining_date() {
		return joining_date;
	}
	public void setJoining_date(String joining_date) {
		this.joining_date = joining_date;
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public float getExperience() {
		return experience;
	}
	public void setExperience(float experience) {
		this.experience = experience;
	}
	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public String getDoor_no() {
		return door_no;
	}

	public void setDoor_no(String door_no) {
		this.door_no = door_no;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
}
