package com.virtusa.payroll.service;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;

public interface AdminService {
	void addEmployeeInfo(Employee e);
	void addAddressInfo(Address a);
	
	void remove(Employee e);
	void addRating(Rating rating);
}
