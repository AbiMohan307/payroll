package com.virtusa.payroll.controller;

import java.sql.Date;
import java.text.ParseException;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Register;
import com.virtusa.payroll.service.AdminService;
import com.virtusa.payroll.service.ChangePasswordService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;

	@Autowired
	ChangePasswordService changePasswordService;
	
	@RequestMapping(value = "/addEmployee", method = RequestMethod.GET)
	public ModelAndView addEmployee(){
		 ModelAndView mav = new ModelAndView("addEmployee");
		 mav.addObject("register", new Register());
		 return mav;
	}
	
	@RequestMapping(value = "/addEmployeeProcess", method = RequestMethod.POST)
	public ModelAndView addEmployeeProcess(HttpSession session,@ModelAttribute("register") Register register) throws ParseException{
		 
		String str=register.getJoining_date();  
	    Date joiningDate=Date.valueOf(str);
		String email= register.getEmail();
		email=email.concat("@virtusa.com");
		String str1=register.getDOB();  
	    Date DOB=Date.valueOf(str);
	    //Employee e=new Employee(emp_id, emp_name, password, email, mobile_no, joining_date, designation_id, experience, location, gender, dOB)
		Employee e=new Employee(register.getEmp_id(),register.getEmp_name(),register.getPassword(),email,register.getMobile_no(), 
				joiningDate,register.getDesignation_id(),register.getExperience(),register.getLocation(),register.getGender(),DOB);
		 
		 Address a=new Address(register.getEmp_id(),register.getDoor_no(),register.getStreet(),register.getCity(),register.getState(),register.getPincode());
	     System.out.println(e.toString()+"   "+a.toString());
		 adminService.addEmployeeInfo(e);
	     adminService.addAddressInfo(a);
		 ModelAndView mav = new ModelAndView("welcome");
		 mav.addObject("message","Registered successfully");
		 return mav;
	}
	
	@RequestMapping(value = "/deleteEmployee", method = RequestMethod.POST)
	public ModelAndView deleteEmployee(HttpSession session){
		 String empid="1";
		 Employee e=changePasswordService.getEmployeeById(empid);
		 adminService.remove(e);
		 ModelAndView mav = new ModelAndView("welcome");
		 mav.addObject("message","Deleted successfully");
		 return mav;
	}
	
	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public ModelAndView resetPassword(){
		 ModelAndView mav = new ModelAndView("resetPassword");
		 return mav;
	}
	@RequestMapping(value = "/reset", method = RequestMethod.POST)
	public ModelAndView reset(@RequestParam(value="emp_id") String emp_id,@RequestParam(value="password") String password){
		 ModelAndView mav = new ModelAndView("welcome");
		 Employee e=changePasswordService.getEmployeeById(emp_id);
		 e.setPassword(password);
		 changePasswordService.updatePassword(e);
		 mav.addObject("message","Password reseted successfully");
		 return mav;
	}
	@RequestMapping(value = "/rateEmployee", method = RequestMethod.POST)
	public ModelAndView rateEmployee(){
		 ModelAndView mav = new ModelAndView("rateEmployee");
		 return mav;
	}
	@RequestMapping(value = "/rate", method = RequestMethod.POST)
	public ModelAndView rate(@RequestParam(value="emp_id") String emp_id,@RequestParam(value="h1_rating") int h1_rating,
			@RequestParam(value="h2_rating") int h2_rating,@RequestParam(value="year") int year){
		Rating rating=new Rating(emp_id, h1_rating, h2_rating, year);
		adminService.addRating(rating);
		ModelAndView mav = new ModelAndView("welcome");
		mav.addObject("message","Rated the employee successfully");
		return mav;
	}
}
