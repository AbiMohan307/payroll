package com.virtusa.payroll.dao;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;

public interface AdminDao {
	void remove(Employee e);
	void addAddressInfo(Address a);
	void addEmployeeInfo(Employee e);
	void addRating(Rating rating);
}
