package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="designation")
public class Designation {

	@Id
	@Column
	int designation_id;
	@Column
	String designation_name;
	@Column
	float per_hour_salary;
	Designation()
	{
		
	}
	public int getDesignation_id() {
		return designation_id;
	}
	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}
	public String getDesignation_name() {
		return designation_name;
	}
	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}
	public float getPer_hour_salary() {
		return per_hour_salary;
	}
	public void setPer_hour_salary(float per_hour_salary) {
		this.per_hour_salary = per_hour_salary;
	}
	public Designation(int designation_id, String designation_name, float per_hour_salary) {
		super();
		this.designation_id = designation_id;
		this.designation_name = designation_name;
		this.per_hour_salary = per_hour_salary;
	}
	
}
