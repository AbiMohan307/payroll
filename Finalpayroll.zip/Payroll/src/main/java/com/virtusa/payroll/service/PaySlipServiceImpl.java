package com.virtusa.payroll.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.payroll.dao.PaySlipDao;
import com.virtusa.payroll.model.Attendance;
import com.virtusa.payroll.model.Designation;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Salary;


@Service
@Transactional
public class PaySlipServiceImpl implements PaySlipService{
	
	@Autowired
	PaySlipDao paySlipDao;

	public List<Salary> getSalary(String empid) {
		// TODO Auto-generated method stub
		return paySlipDao.getSalary(empid);
	}
	@Transactional
	public void setPaySlipDao(PaySlipDao paySlipDao) {
		this.paySlipDao = paySlipDao;
	}
	@Transactional
	public List<Attendance> getHoursWorked(String empid, String month, int year) {
		// TODO Auto-generated method stub
		return paySlipDao.getHoursWorked(empid, month, year);
	}
	@Transactional
	public List<Employee> getEmployee(String empid) {
		// TODO Auto-generated method stub
		return paySlipDao.getEmployee(empid);
	}
	@Transactional
	public List<Designation> getDesignation(int designation_id) {
		// TODO Auto-generated method stub
		return paySlipDao.getDesignation(designation_id);
	}

}
