package com.virtusa.payroll.dao;


import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;

public interface UpdateDAO {
	public Employee getEmployeeById(String empid);
	public Address getAddressById(String empid);
	
	public void updateEmployeeInfo(Employee e);
	public void updateAddress(Address a);
	
}
