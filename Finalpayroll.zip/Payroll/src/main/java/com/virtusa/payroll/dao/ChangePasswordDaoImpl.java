package com.virtusa.payroll.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Employee;

@Repository   
public class ChangePasswordDaoImpl implements ChangePasswordDao{

	
	@Autowired
	SessionFactory sessionFactory;
	
	public Employee getEmployeeById(String empid) {
		// TODO Auto-generated method stub
		return (Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
	}
	

	public void updatePassword(Employee employee) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(employee);
	}


}
