package com.virtusa.payroll.service;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Salary;

public interface AdminService {
	void addEmployeeInfo(Employee e);
	void addAddressInfo(Address a);
	
	void addRating(Rating rating);
	void remove(Employee e, Address a, Salary s, String emp_id);
}
