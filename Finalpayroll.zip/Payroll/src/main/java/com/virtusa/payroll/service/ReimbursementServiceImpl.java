package com.virtusa.payroll.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.payroll.dao.ReimbursementDao;
import com.virtusa.payroll.model.Reimbursement;


@Service
@Transactional
public class ReimbursementServiceImpl implements ReimbursementService {

	@Autowired
	ReimbursementDao reimbursementDao;
	
	public void setReimbursementDao(ReimbursementDao reimbursementDao) {
		this.reimbursementDao = reimbursementDao;
	}

	@Transactional
	public List<Reimbursement> getdetails(String empid) {
		 return reimbursementDao.getdetails(empid);
	}
	@Transactional
	public List<Reimbursement> getClaimDetails(String empid, String claimType) {
		return reimbursementDao.getClaimDetails(empid,claimType);
	}
	@Transactional
	public void updateClaim(Reimbursement reim) {
		reimbursementDao.updateClaim(reim);
		
	}
}
