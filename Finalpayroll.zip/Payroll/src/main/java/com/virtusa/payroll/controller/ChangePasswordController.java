package com.virtusa.payroll.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.service.ChangePasswordService;


@Controller
public class ChangePasswordController {
	
@Autowired
ChangePasswordService changePasswordService;

@RequestMapping(value = "/setPassword", method = RequestMethod.GET)
public ModelAndView setPassword(){
	 ModelAndView mav = new ModelAndView("setPassword");
	 String empid="1";
	 Employee employee=changePasswordService.getEmployeeById(empid);
	 mav.addObject("employee", employee);
	 return mav;
}

@RequestMapping(value = "/change", method = RequestMethod.POST)
public ModelAndView change(HttpSession session,
    @RequestParam("oldPassword") String oldPassword,
    @RequestParam("newPassword") String newPassword,
    @RequestParam("confirmPassword") String confirmPassword) {

	  ModelAndView mav = null;
	  String empid="1";
	  Employee employee=changePasswordService.getEmployeeById(empid);

  if(oldPassword.equals(newPassword)) {
	
    mav = new ModelAndView("setPassword");
    mav.addObject("employee",employee);
    mav.addObject("message", "old Password and new Password should be different ");
  }
  else if(!newPassword.equals(confirmPassword)) {
	
    mav = new ModelAndView("setPassword");
    mav.addObject("employee",employee);
    mav.addObject("message", "new Password and confirm Password should be same");
  }
  else {
	
    employee.setPassword(newPassword);
    changePasswordService.updatePassword(employee);
    mav = new ModelAndView("welcome");
    mav.addObject("employee",employee);
    mav.addObject("message", "Password changed successful");
  }
  return mav;

}
 
}
