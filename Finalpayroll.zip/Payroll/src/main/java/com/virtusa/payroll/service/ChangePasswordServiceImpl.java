package com.virtusa.payroll.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.ChangePasswordDao;
import com.virtusa.payroll.model.Employee;

@Service
@Transactional
public class ChangePasswordServiceImpl implements ChangePasswordService{
	
	@Autowired
	ChangePasswordDao changePasswordDao;
	public void setChangePassworddao(ChangePasswordDao changePassworddao) {
		this.changePasswordDao = changePassworddao;
	}
	@Transactional
	public Employee getEmployeeById(String empid) {
		return changePasswordDao.getEmployeeById(empid);
	}
	
	@Transactional
	public void updatePassword(Employee employee) {
		changePasswordDao.updatePassword(employee);		
	}
	
	

}
