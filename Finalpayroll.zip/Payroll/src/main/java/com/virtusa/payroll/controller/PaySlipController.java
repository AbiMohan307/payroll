package com.virtusa.payroll.controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Attendance;
import com.virtusa.payroll.model.Designation;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Payslip;
import com.virtusa.payroll.model.Salary;
import com.virtusa.payroll.model.Year;
import com.virtusa.payroll.service.PaySlipService;



@Controller

public class PaySlipController {
	
	@Autowired
	PaySlipService paySlipService;
	@RequestMapping(value="/payslip",method=RequestMethod.GET)
	public ModelAndView selectOption(HttpServletRequest request,HttpServletResponse response)
	{
		ModelAndView mav=new ModelAndView("payslip");
		return mav;
		
	}
	@RequestMapping(value="/GeneratePayslip",method=RequestMethod.POST)
	public String showPaySlip(HttpSession session,
			@ModelAttribute("year") Year year,ModelMap mav)
	{
		
		System.out.println(year.getYear()+" "+year.getMonth());
		String empid="1";
		List<Attendance> hoursWorked=paySlipService.getHoursWorked(empid, year.getMonth(), year.getYear());
		List<Salary> ctc=paySlipService.getSalary(empid);
		List<Employee> employee=paySlipService.getEmployee(empid);
		List<Designation> designation=paySlipService.getDesignation(employee.get(0).getDesignation_id());
		mav.addAttribute("hoursWorked", hoursWorked);
		System.out.println(ctc.get(0).getCtc());
		
		float yearly_basic=(float) ((0.4)*(ctc.get(0).getCtc()));
		float yearly_HRA=(float) ((0.5)*(yearly_basic));
		float yearly_pf=(float) ((0.155)*(yearly_basic));
		float basic=(float) ((0.4)*(ctc.get(0).getCtc())/12);
		float HRA=(float) (yearly_HRA/12);
		float pf=(float) (yearly_pf/12);
		float y_employee_esi_pay=(float)(yearly_basic*0.0172);
		float y_employer_esi_pay=(float)(yearly_basic*0.0375);
		float y_ESI=y_employee_esi_pay+y_employer_esi_pay;
		float employee_esi_pay=(float)(basic*0.0172);
		float employer_esi_pay=(float)(basic*0.0375);
		float ESI=employee_esi_pay+employer_esi_pay;
		System.out.println(basic+" "+HRA);
		mav.addAttribute("year", year);
		mav.addAttribute("designation", designation);
		mav.addAttribute("employee", employee);
		Payslip payslip=new Payslip(empid, employee.get(0).getEmp_name(),employee.get(0).getLocation(),designation.get(0).getDesignation_name() ,  employee.get(0).getGender()
				, basic, yearly_basic, pf, yearly_pf, HRA, yearly_HRA, ESI, y_ESI);
		
		mav.addAttribute("payslip", payslip);
		return "showPaySlip";
		
	}
	@RequestMapping(value="/downloadPdf",method=RequestMethod.POST) 
	public ModelAndView downloadPdf(@ModelAttribute("payslip") Payslip payslipDisplay)
	{
		System.out.println(213234);
		//System.out.println(payslipDisplay.getDesignation());
		return new ModelAndView("pdf2","payslipDisplay",payslipDisplay);
		
	}
}
