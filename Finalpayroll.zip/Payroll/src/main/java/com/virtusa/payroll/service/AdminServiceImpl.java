package com.virtusa.payroll.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.AdminDao;
import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Rating;
import com.virtusa.payroll.model.Salary;

@Service
@Transactional
public class AdminServiceImpl implements AdminService{

	@Autowired
	AdminDao adminDao;
	
	public void addEmployeeInfo(Employee e) {
		adminDao.addEmployeeInfo(e); 
		
	}
	
	public void addAddressInfo(Address a) {
		adminDao.addAddressInfo(a); 
		
	}
	
	

	public void addRating(Rating rating) {
		adminDao.addRating(rating);
		
	}


	public void remove(Employee e, Address a, Salary s, String emp_id) {
		adminDao.remove(e,a,s,emp_id);
		
	}


}
