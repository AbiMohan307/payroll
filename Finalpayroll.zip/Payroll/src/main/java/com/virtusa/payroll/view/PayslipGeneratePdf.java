package com.virtusa.payroll.view;

import java.text.SimpleDateFormat;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.virtusa.payroll.model.Payslip;

public class PayslipGeneratePdf extends AbstractPdfView{

	@Override
	protected void buildPdfDocument(Map<String, Object> map, Document document, PdfWriter pdfWriter, HttpServletRequest request,
			HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub

		Payslip payslip =(Payslip) map.get("payslipDisplay");
		
		PdfPTable table = new PdfPTable(2);
		 table.setWidths(new int[]{40, 60});
		 document.addTitle("Vitusa Consulting Services Private Limited");
		 Paragraph paragraph=new Paragraph("                           Vitusa Consulting Services Private Limited");
		 document.add(paragraph);
		 Paragraph paragraph2=new Paragraph("\n");
		 document.add(paragraph2);
		 Paragraph paragraph1=new Paragraph("                                  PaySlip for Selected Month");
		 document.add(paragraph1);
		 document.add(paragraph2);
		table.addCell("Employee_Id");
		table.addCell(payslip.getEmpid());
		table.addCell("Employee Name");
		table.addCell(payslip.getEmp_name());
		table.addCell("Location");
		table.addCell(payslip.getLocation());
		/*table.addCell("DOB");
		table.addCell(new SimpleDateFormat("yyyy-mm-dd").format(payslip.getDob()));*/
		table.addCell("Gender");
		table.addCell(payslip.getGender());
		/*table.addCell("Joining Date");
		table.addCell(new SimpleDateFormat("yyyy-mm-dd").format(payslip.getJoining_date()));*/
		table.addCell("Designation");
		table.addCell(payslip.getDesignation());
		table.addCell("Basic");
		table.addCell(Float.toString(payslip.getBasic()));
		table.addCell("Yearly Basic");
		table.addCell(Float.toString(payslip.getYearly_basic()));
		table.addCell("HRA");
		table.addCell(Float.toString(payslip.getHRA()));
		table.addCell("Yearly HRA");
		table.addCell(Float.toString(payslip.getYearly_HRA()));
		table.addCell("PF");
		table.addCell(Float.toString(payslip.getPf()));
		table.addCell("Yearly PF");
		table.addCell(Float.toString(payslip.getPf()));
		table.addCell("ESI");
		table.addCell(Float.toString(payslip.getESI()));
		table.addCell("Yearly ESI");
		table.addCell(Float.toString(payslip.getY_ESI()));
		 document.add(table);
	}

}
