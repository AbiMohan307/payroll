package com.virtusa.payroll.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.ChangePasswordDao;
import com.virtusa.payroll.model.User;

@Service
@Transactional
public class ChangePasswordServiceImpl implements ChangePasswordService{
	
	@Autowired
	ChangePasswordDao changePasswordDao;
	public void setChangePassworddao(ChangePasswordDao changePassworddao) {
		this.changePasswordDao = changePassworddao;
	}
	@Transactional
	public User getUserById(int empid) {
		// TODO Auto-generated method stub
		return changePasswordDao.getUserById(empid);
	}
	@Transactional
	public List<User> listUsers() {
		// TODO Auto-generated method stub
		return changePasswordDao.listUsers();
	}
	@Transactional
	public void updatePassword(User user, String newPassword) {
		// TODO Auto-generated method stub
		changePasswordDao.updatePassword(user, newPassword);		
	}
	
	

}
