package com.virtusa.payroll.dao;

import java.sql.Date;
import java.time.LocalDate;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Mbo;


@Repository
public class MboDaoImpl implements MboDao
{		
		@Autowired
		SessionFactory sessionFactory;

		
	public int MBOPayout(int empid)
	{
		Date date=null;
		Employee employee=(Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
		date = employee.getJoining_date();
		LocalDate localDate = date.toLocalDate();
		int year = localDate.getYear();	
        return year;
}
		
	public float getMBO(int year,String quarter,int eid) {
			float amount = 0;
			Mbo mbo=(Mbo) sessionFactory.getCurrentSession().get(Mbo.class, eid);
			if(quarter.equals("mbo1")) {
				amount = mbo.getMbo1();
			}
			else if(quarter.equals("mbo2")) {
				amount = mbo.getMbo2();
			}
			else if(quarter.equals("mbo3")) {
				amount = mbo.getMbo3();
			}
			else {
				amount = mbo.getMbo4();
			}
			
			return amount;
		
	}
		
		public Employee getUserById(int empid) {
			
			return (Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
		}
		

}
