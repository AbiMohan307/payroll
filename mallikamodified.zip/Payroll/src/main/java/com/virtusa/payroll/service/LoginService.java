package com.virtusa.payroll.service;



import com.virtusa.payroll.model.User;


public interface LoginService {
	
	public int validateEmployee(User login);
	
	
}
