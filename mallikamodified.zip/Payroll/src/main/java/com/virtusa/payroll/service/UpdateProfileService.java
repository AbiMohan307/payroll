package com.virtusa.payroll.service;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;

public interface UpdateProfileService {
	
	public Employee getEmployeeById(int empid);
	public Address getAddressById(int empid);
	

	public void updateAddress(Address a);

	public void updateEmployeeInfo(Employee e);

}
