package com.virtusa.payroll.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Mbo;
import com.virtusa.payroll.model.MboPay;
import com.virtusa.payroll.service.MboPayoutService;


@Controller
public class MBOPayoutController {
	
	@Autowired
	MboPayoutService mboPayoutService;
	
	@RequestMapping(value = "/mbo", method = RequestMethod.GET)
	  public String mbo(ModelMap mav){
		// ModelAndView mav = new ModelAndView();
		 int year = mboPayoutService.MBOPayout(2);
		/* 	((ModelAndView) mav).addObject("year", year);
			mav.addObject("mbo",new MboPay());
		mav.setViewName("mbo"); */
		 mav.addAttribute("mbo", new MboPay());
		 mav.addAttribute("joining", year);
		 
		return "mbo";
		
	}
	
	@RequestMapping(value = "/mboPayout", method = RequestMethod.POST)
	public ModelAndView mboPayout(HttpServletRequest request, HttpServletResponse response,HttpSession session,
			 @RequestParam("year") int year,@RequestParam("quarter") String quarter,
		      @ModelAttribute("mbo") Mbo mbo) {
		 ModelAndView mav = new ModelAndView();
		 int empid=(Integer) session.getAttribute("empid");
		float amount = mboPayoutService.getMBO(year, quarter, empid);
		mav.addObject("mbo", amount);
		mav.setViewName("mboDisplay");
		return mav;
		    	  
		      }
}
	
	
	

