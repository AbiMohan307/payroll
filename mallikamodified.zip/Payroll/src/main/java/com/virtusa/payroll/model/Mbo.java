package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mbo")
public class Mbo {
	
	@Id
	@Column
	int e_id;
	@Column
	int year;
	@Column
	float mbo1;
	@Column
	float mbo2;
	@Column
	float mbo3;
	@Column
	float mbo4;
	
	public Mbo() {
		// TODO Auto-generated constructor stub
	}
	public Mbo(int e_id, int year, float mbo1, float mbo2, float mbo3, float mbo4) {
		this.e_id = e_id;
		this.year = year;
		this.mbo1 = mbo1;
		this.mbo2 = mbo2;
		this.mbo3 = mbo3;
		this.mbo4 = mbo4;
	}
	public int getE_id() {
		return e_id;
	}
	public void setE_id(int e_id) {
		this.e_id = e_id;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getMbo1() {
		return mbo1;
	}
	public void setMbo1(float mbo1) {
		this.mbo1 = mbo1;
	}
	public float getMbo2() {
		return mbo2;
	}
	public void setMbo2(float mbo2) {
		this.mbo2 = mbo2;
	}
	public float getMbo3() {
		return mbo3;
	}
	public void setMbo3(float mbo3) {
		this.mbo3 = mbo3;
	}
	public float getMbo4() {
		return mbo4;
	}
	public void setMbo4(float mbo4) {
		this.mbo4 = mbo4;
	}
	@Override
	public String toString() {
		return "Mbo [e_id=" + e_id + ", year=" + year + ", mbo1=" + mbo1 + ", mbo2=" + mbo2 + ", mbo3=" + mbo3
				+ ", mbo4=" + mbo4 + "]";
	}
	
}
