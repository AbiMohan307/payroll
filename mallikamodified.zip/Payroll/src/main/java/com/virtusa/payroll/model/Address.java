package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address {

	@Column
	String address;
	@Column
	int city_id;
	@Column
	int state_id;
	@Column
	String pincode;
	@Id
	@Column
	int emp_id;

public Address() {
	super();
	// TODO Auto-generated constructor stub
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public int getCity_id() {
	return city_id;
}

public void setCity_id(int city_id) {
	this.city_id = city_id;
}

public int getState_id() {
	return state_id;
}

public void setState_id(int state_id) {
	this.state_id = state_id;
}

public String getPincode() {
	return pincode;
}

public void setPincode(String pincode) {
	this.pincode = pincode;
}

public int getEmp_id() {
	return emp_id;
}

public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}

public Address(String address, int city_id, int state_id, String pincode, int emp_id) {
	super();
	this.address = address;
	this.city_id = city_id;
	this.state_id = state_id;
	this.pincode = pincode;
	this.emp_id = emp_id;
}
}
