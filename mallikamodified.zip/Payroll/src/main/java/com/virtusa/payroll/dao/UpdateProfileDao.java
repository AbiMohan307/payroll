package com.virtusa.payroll.dao;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;

public interface UpdateProfileDao {

	public Employee getEmployeeById(int empid);
	public Address getAddressById(int empid);
	
	public void updateEmployeeInfo(Employee e);
	public void updateAddress(Address a);
}
