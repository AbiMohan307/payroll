package com.virtusa.payroll.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.payroll.dao.PaySlipDao;
import com.virtusa.payroll.model.Salary;


@Service
@Transactional
public class PaySlipServiceImpl implements PaySlipService{
	
	@Autowired
	PaySlipDao paySlipDao;
	
	@Transactional
	public List<Salary> getSalary(int empid, int year, String month) {
		// TODO Auto-generated method stub
		return paySlipDao.getSalary( empid,year,month);
	}
	
	public void setPaySlipDao(PaySlipDao paySlipDao)
	{
		this.paySlipDao=paySlipDao;
	}

}
