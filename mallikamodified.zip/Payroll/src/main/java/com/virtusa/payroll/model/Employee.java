package com.virtusa.payroll.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	@Column
	 int emp_id;
	@Column
	 String emp_name;
	@Column
	 String email_id;
	@Column
	 String contact_number;
	@Column
	 Date joining_date;
	@Column
	 int hr_id;
	@Column
     int dept_id;
	@Column
	 int manager_id;
	@Column
	 float experience;

	  public Employee() {  }

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public Date getJoining_date() {
		return joining_date;
	}

	public void setJoining_date(Date joining_date) {
		this.joining_date = joining_date;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public int getHr_id() {
		return hr_id;
	}

	public void setHr_id(int hr_id) {
		this.hr_id = hr_id;
	}

	public int getDept_id() {
		return dept_id;
	}

	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}

	public int getManager_id() {
		return manager_id;
	}

	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}

	public float getExperience() {
		return experience;
	}

	public void setExperience(float experience) {
		this.experience = experience;
	}

	public Employee(int emp_id, String emp_name, String email_id, String contact_number, Date joining_date, int hr_id,
			int dept_id, int manager_id, float experience) {
		super();
		this.emp_id = emp_id;
		this.joining_date = joining_date;
		this.emp_name = emp_name;
		this.email_id = email_id;
		this.contact_number = contact_number;
		this.hr_id = hr_id;
		this.dept_id = dept_id;
		this.manager_id = manager_id;
		this.experience = experience;
	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", email_id=" + email_id + ", contact_number="
				+ contact_number + ", joining_date=" + joining_date + ", hr_id=" + hr_id + ", dept_id=" + dept_id
				+ ", manager_id=" + manager_id + ", experience=" + experience + "]";
	}
	
	  
	
}
