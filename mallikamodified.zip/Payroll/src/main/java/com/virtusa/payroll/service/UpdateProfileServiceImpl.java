package com.virtusa.payroll.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.payroll.dao.UpdateProfileDao;
import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
@Service
@Transactional
public class UpdateProfileServiceImpl implements UpdateProfileService{

	@Autowired
	UpdateProfileDao updateProfileDAO;
	
	
	public Employee getEmployeeById(int empid) {
		return updateProfileDAO.getEmployeeById(empid);
	}
	public Address getAddressById(int empid) {
		// TODO Auto-generated method stub
		return updateProfileDAO.getAddressById(empid);
	}
	public void updateAddress(Address a) {
		updateProfileDAO.updateAddress(a);
		
	}

	public void updateEmployeeInfo(Employee e) {
		updateProfileDAO.updateEmployeeInfo(e);
		
	}


}
