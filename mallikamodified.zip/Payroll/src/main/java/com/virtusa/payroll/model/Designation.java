package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="designation")
public class Designation {
	
	@Id
	@Column
	int designation_id;
	@Column
	String designation;

	public int getDesignation_id() {
		return designation_id;
	}

	public void setDesignation_id(int designation_id) {
		this.designation_id = designation_id;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Designation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Designation(String designation) {
		super();
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Designation [designation=" + designation + "]";
	}
	
}
