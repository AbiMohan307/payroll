package com.virtusa.payroll.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.payroll.model.Address;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Update;
import com.virtusa.payroll.service.UpdateProfileService;
@Controller
public class UpdateProfileController {
	@Autowired
	UpdateProfileService updateService;
	
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	  public ModelAndView update(HttpSession session){
		ModelAndView mav = new ModelAndView();
		int empid=(Integer) session.getAttribute("empid");

		 Employee employee=updateService.getEmployeeById(empid);
		 Address add=updateService.getAddressById(empid);
		 System.out.println(employee.toString());
		 mav.addObject("employee",employee);
		 mav.addObject("add",add);
		mav.setViewName("updateProfileDisplay");
		return mav;
		
	}
	@RequestMapping(value = "/updatep", method = RequestMethod.GET)
	  public ModelAndView updatep(){
		ModelAndView mav = new ModelAndView();
		Update update=new Update();
		mav.addObject("update",update);
		mav.setViewName("updateProfileEnterDetails");
		return mav;
		
	}
	@RequestMapping(value = "/updateProcess", method = RequestMethod.POST)
	  public ModelAndView updatePassword(HttpServletRequest request, HttpServletResponse response,
			  @RequestParam(value = "email_id",defaultValue = "null") String email_id, 
			  @RequestParam(value = "contact_number", defaultValue = "null") String contact_number, 
			  @RequestParam(value = "address",defaultValue = "null") String address,
	      @ModelAttribute("update") Update update) {
	  
	   int empid = 2;
	   ModelAndView mav = null;
	      
	    Employee employee=updateService.getEmployeeById(empid);
	    Address addressObj=updateService.getAddressById(empid);
	     
	    Employee e;
	   
	    if(!email_id.isEmpty() && !contact_number.isEmpty()) {
	    	
	    e=new Employee(employee.getEmp_id(), employee.getEmp_name(), email_id, contact_number,
				employee.getJoining_date(),employee.getHr_id(),employee.getDept_id(),employee.getManager_id(), employee.getExperience());
	    updateService.updateEmployeeInfo(e);
	 	
		}
	    else if(!email_id.isEmpty() && contact_number.isEmpty()){
	    
	    	 e=new Employee(employee.getEmp_id(), employee.getEmp_name(), email_id, employee.getContact_number(),
	 				employee.getJoining_date(),employee.getHr_id(),employee.getDept_id(),employee.getManager_id(), employee.getExperience());
	 	    updateService.updateEmployeeInfo(e);
	    }
	    else if(email_id.isEmpty() && !contact_number.isEmpty()) {
	    	
	    	 e=new Employee(employee.getEmp_id(), employee.getEmp_name(), employee.getEmail_id(), contact_number,
	 				employee.getJoining_date(),employee.getHr_id(),employee.getDept_id(),employee.getManager_id(), employee.getExperience());
	 	    updateService.updateEmployeeInfo(e);
	    }
	    else {
	    	e = updateService.getEmployeeById(empid);
	    }
	    Address a;
	    if(!address.isEmpty()) {
	    a=new Address(address, addressObj.getCity_id(),addressObj.getState_id(),
	    		addressObj.getPincode(), addressObj.getEmp_id());
		updateService.updateAddress(a);
		}
	    else {
	    	a = updateService.getAddressById(empid);
	    }
	    System.out.println("Address="+a.getAddress());
		
	      mav = new ModelAndView("updateProfileDisplay");
	      mav.addObject("employee",e);
	      mav.addObject("add",a);
	      mav.addObject("message", "Password change successful");
	      return mav;
	    }

}
