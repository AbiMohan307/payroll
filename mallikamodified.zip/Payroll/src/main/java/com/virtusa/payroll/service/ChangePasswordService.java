package com.virtusa.payroll.service;

import java.util.List;

import com.virtusa.payroll.model.User;

public interface ChangePasswordService {

		
	public User getUserById(int empid);
	
	public List<User> listUsers();

	public void updatePassword(User user, String newPassword);
}
