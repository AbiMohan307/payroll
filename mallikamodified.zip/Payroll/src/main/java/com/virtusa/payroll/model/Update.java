package com.virtusa.payroll.model;

public class Update {
		
	 private String email_id;
	  private String contact_number;
	  private String address;
	public Update(String email_id, String contact_number, String address) {
		super();
		this.email_id = email_id;
		this.contact_number = contact_number;
		this.address = address;
	}
	public Update() {
		// TODO Auto-generated constructor stub
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	  
	

}
