package com.virtusa.payroll.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.payroll.model.Salary;



@Repository
public class PaySlipDaoImpl implements PaySlipDao{

	@Autowired
	SessionFactory sessionFactory;
	@SuppressWarnings("unchecked")
	public List<Salary> getSalary(int empid, int year, String month) {
		// TODO Auto-generated method stub
		Query query=sessionFactory.getCurrentSession().createQuery("from Salary s where s.empid=:empid "
				+ "and s.year=:year"
				+ " and s.month=:month");
		query.setParameter("empid",empid);
		query.setParameter("year",year);
		query.setParameter("month",month);
		return  query.list();
		
	}

}
